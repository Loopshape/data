<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'gosignsql1');

/** MySQL database username */
define('DB_USER', 'gosignsql1');

/** MySQL database password */
define('DB_PASSWORD', 'gosignsql1');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'N8~|ue8{rPhjlE/K}rEQc%tHLVh$bP4-w,w~/OPmmlcl08B  kF4RCCIb}B|PL4(');
define('SECURE_AUTH_KEY',  '1jDI!NoUQ4sJd(b#9Wq8(8K{tH:$~2s*-QI9X^EtteKSAbZ~FO[1]]}QJ`7j$SZF');
define('LOGGED_IN_KEY',    'w<qRN=7-~9+m-r`FR/[4>iV(P9)_Aed)Tw<$[HR6i-c6Do9#%!I+Tx[hL@nid2=N');
define('NONCE_KEY',        '0PuZk!^SoBUYRrtzOM[=zA}`kw+M-Qzf0ES28mIO-{8`Y39LWdOR-.d#)7~c@bou');
define('AUTH_SALT',        '#k8:0|HEjH4Z(5RvN@hwL!Iuh$O<@.S26%1q6;&;2-5Ft!p3~byy=Epp}~Z|]D-.');
define('SECURE_AUTH_SALT', 'nF+|YlzbTN!Y%o&?%k)>fD)!T&hc-1tPJ,,[q[]aVG=]Tb!h_/Mhwokz^IXv7?:+');
define('LOGGED_IN_SALT',   '1G%-_BF_X%gy+Z@S7D]!fwT[q:d|?7b7=-5f$,S&:BILfm8e,9ZQ)UxF1(?,x9s-');
define('NONCE_SALT',       'S]X(}dOj)Z+o9_?8DtS2txS%++&W^(T,ZNx%.VQ<Ip)Bw.rfw{]<E4<j+@|Ny]7]');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
