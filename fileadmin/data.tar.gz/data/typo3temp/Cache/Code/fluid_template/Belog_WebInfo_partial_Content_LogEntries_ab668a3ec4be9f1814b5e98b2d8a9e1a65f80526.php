<?php
class FluidCache_Belog_WebInfo_partial_Content_LogEntries_ab668a3ec4be9f1814b5e98b2d8a9e1a65f80526 extends \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate {

public function getVariableContainer() {
	// TODO
	return new \TYPO3\CMS\Fluid\Core\ViewHelper\TemplateVariableContainer();
}
public function getLayoutName(\TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {

return NULL;
}
public function hasLayout() {
return FALSE;
}

/**
 * Main Render function
 */
public function render(\TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$self = $this;
$output0 = '';

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments1 = array();
// Rendering Boolean node
$arguments1['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.groupByPage', $renderingContext));
$arguments1['then'] = NULL;
$arguments1['else'] = NULL;
$renderChildrenClosure2 = function() use ($renderingContext, $self) {
$output3 = '';

$output3 .= '
	<div>
		<h2>
			';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments4 = array();
$arguments4['key'] = 'overview';
$arguments4['id'] = NULL;
$arguments4['default'] = NULL;
$arguments4['htmlEscape'] = NULL;
$arguments4['arguments'] = NULL;
$arguments4['extensionName'] = NULL;
$renderChildrenClosure5 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper6 = $self->getViewHelper('$viewHelper6', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper6->setArguments($arguments4);
$viewHelper6->setRenderingContext($renderingContext);
$viewHelper6->setRenderChildrenClosure($renderChildrenClosure5);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output3 .= $viewHelper6->initializeArgumentsAndRender();

$output3 .= '
		</h2>
		';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments7 = array();
$arguments7['key'] = 'timeInfo';
// Rendering Array
$array8 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments9 = array();
$output10 = '';

$output10 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output10 .= ' H:i';
$arguments9['format'] = $output10;
$output11 = '';

$output11 .= '@';

$output11 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments9['date'] = $output11;
$renderChildrenClosure12 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper13 = $self->getViewHelper('$viewHelper13', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper13->setArguments($arguments9);
$viewHelper13->setRenderingContext($renderingContext);
$viewHelper13->setRenderChildrenClosure($renderChildrenClosure12);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array8['0'] = $viewHelper13->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments14 = array();
$output15 = '';

$output15 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output15 .= ' H:i';
$arguments14['format'] = $output15;
$output16 = '';

$output16 .= '@';

$output16 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments14['date'] = $output16;
$renderChildrenClosure17 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper18 = $self->getViewHelper('$viewHelper18', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper18->setArguments($arguments14);
$viewHelper18->setRenderingContext($renderingContext);
$viewHelper18->setRenderChildrenClosure($renderChildrenClosure17);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array8['1'] = $viewHelper18->initializeArgumentsAndRender();
$arguments7['arguments'] = $array8;
$arguments7['id'] = NULL;
$arguments7['default'] = NULL;
$arguments7['htmlEscape'] = NULL;
$arguments7['extensionName'] = NULL;
$renderChildrenClosure19 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper20 = $self->getViewHelper('$viewHelper20', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper20->setArguments($arguments7);
$viewHelper20->setRenderingContext($renderingContext);
$viewHelper20->setRenderChildrenClosure($renderChildrenClosure19);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output3 .= $viewHelper20->initializeArgumentsAndRender();

$output3 .= '
		<p>
			';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper
$arguments21 = array();
$arguments21['each'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'groupedLogEntries', $renderingContext);
$arguments21['as'] = 'pidEntry';
$arguments21['key'] = 'pid';
$arguments21['reverse'] = false;
$arguments21['iteration'] = NULL;
$renderChildrenClosure22 = function() use ($renderingContext, $self) {
$output23 = '';

$output23 .= '
				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments24 = array();
// Rendering Boolean node
$arguments24['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('>', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 0);
$arguments24['then'] = NULL;
$arguments24['else'] = NULL;
$renderChildrenClosure25 = function() use ($renderingContext, $self) {
$output26 = '';

$output26 .= '
					<br />
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments27 = array();
$arguments27['key'] = 'pagenameWithUID';
// Rendering Array
$array28 = array();
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$arguments29 = array();
$arguments29['pid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments29['titleLimit'] = 20;
$renderChildrenClosure30 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper31 = $self->getViewHelper('$viewHelper31', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper');
$viewHelper31->setArguments($arguments29);
$viewHelper31->setRenderingContext($renderingContext);
$viewHelper31->setRenderChildrenClosure($renderChildrenClosure30);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$array28['0'] = $viewHelper31->initializeArgumentsAndRender();
$array28['1'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments27['arguments'] = $array28;
$arguments27['id'] = NULL;
$arguments27['default'] = NULL;
$arguments27['htmlEscape'] = NULL;
$arguments27['extensionName'] = NULL;
$renderChildrenClosure32 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper33 = $self->getViewHelper('$viewHelper33', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper33->setArguments($arguments27);
$viewHelper33->setRenderingContext($renderingContext);
$viewHelper33->setRenderChildrenClosure($renderChildrenClosure32);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output26 .= $viewHelper33->initializeArgumentsAndRender();

$output26 .= '
				';
return $output26;
};
$viewHelper34 = $self->getViewHelper('$viewHelper34', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper34->setArguments($arguments24);
$viewHelper34->setRenderingContext($renderingContext);
$viewHelper34->setRenderChildrenClosure($renderChildrenClosure25);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output23 .= $viewHelper34->initializeArgumentsAndRender();

$output23 .= '
			';
return $output23;
};

$output3 .= TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper::renderStatic($arguments21, $renderChildrenClosure22, $renderingContext);

$output3 .= '
		</p>
	</div>
';
return $output3;
};
$viewHelper35 = $self->getViewHelper('$viewHelper35', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper35->setArguments($arguments1);
$viewHelper35->setRenderingContext($renderingContext);
$viewHelper35->setRenderChildrenClosure($renderChildrenClosure2);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output0 .= $viewHelper35->initializeArgumentsAndRender();

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper
$arguments36 = array();
$arguments36['each'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'groupedLogEntries', $renderingContext);
$arguments36['as'] = 'pidEntry';
$arguments36['key'] = 'pid';
$arguments36['reverse'] = false;
$arguments36['iteration'] = NULL;
$renderChildrenClosure37 = function() use ($renderingContext, $self) {
$output38 = '';

$output38 .= '
	<div>
		<h2>
			';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments39 = array();
// Rendering Boolean node
$arguments39['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.groupByPage', $renderingContext));
$arguments39['then'] = NULL;
$arguments39['else'] = NULL;
$renderChildrenClosure40 = function() use ($renderingContext, $self) {
$output41 = '';

$output41 .= '
				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments42 = array();
$renderChildrenClosure43 = function() use ($renderingContext, $self) {
$output44 = '';

$output44 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments45 = array();
// Rendering Boolean node
$arguments45['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('<', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 1);
$arguments45['then'] = NULL;
$arguments45['else'] = NULL;
$renderChildrenClosure46 = function() use ($renderingContext, $self) {
$output47 = '';

$output47 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments48 = array();
$renderChildrenClosure49 = function() use ($renderingContext, $self) {
$output50 = '';

$output50 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments51 = array();
// Rendering Boolean node
$arguments51['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), -1);
$arguments51['then'] = NULL;
$arguments51['else'] = NULL;
$renderChildrenClosure52 = function() use ($renderingContext, $self) {
$output53 = '';

$output53 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments54 = array();
$arguments54['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array55 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments56 = array();
$arguments56['key'] = 'forNonPageRelatedActions';
$arguments56['id'] = NULL;
$arguments56['default'] = NULL;
$arguments56['htmlEscape'] = NULL;
$arguments56['arguments'] = NULL;
$arguments56['extensionName'] = NULL;
$renderChildrenClosure57 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper58 = $self->getViewHelper('$viewHelper58', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper58->setArguments($arguments56);
$viewHelper58->setRenderingContext($renderingContext);
$viewHelper58->setRenderChildrenClosure($renderChildrenClosure57);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array55['0'] = $viewHelper58->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments59 = array();
$output60 = '';

$output60 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output60 .= ' H:i';
$arguments59['format'] = $output60;
$output61 = '';

$output61 .= '@';

$output61 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments59['date'] = $output61;
$renderChildrenClosure62 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper63 = $self->getViewHelper('$viewHelper63', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper63->setArguments($arguments59);
$viewHelper63->setRenderingContext($renderingContext);
$viewHelper63->setRenderChildrenClosure($renderChildrenClosure62);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array55['1'] = $viewHelper63->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments64 = array();
$output65 = '';

$output65 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output65 .= ' H:i';
$arguments64['format'] = $output65;
$output66 = '';

$output66 .= '@';

$output66 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments64['date'] = $output66;
$renderChildrenClosure67 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper68 = $self->getViewHelper('$viewHelper68', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper68->setArguments($arguments64);
$viewHelper68->setRenderingContext($renderingContext);
$viewHelper68->setRenderChildrenClosure($renderChildrenClosure67);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array55['2'] = $viewHelper68->initializeArgumentsAndRender();
$arguments54['arguments'] = $array55;
$arguments54['id'] = NULL;
$arguments54['default'] = NULL;
$arguments54['htmlEscape'] = NULL;
$arguments54['extensionName'] = NULL;
$renderChildrenClosure69 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper70 = $self->getViewHelper('$viewHelper70', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper70->setArguments($arguments54);
$viewHelper70->setRenderingContext($renderingContext);
$viewHelper70->setRenderChildrenClosure($renderChildrenClosure69);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output53 .= $viewHelper70->initializeArgumentsAndRender();

$output53 .= '
							';
return $output53;
};
$viewHelper71 = $self->getViewHelper('$viewHelper71', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper71->setArguments($arguments51);
$viewHelper71->setRenderingContext($renderingContext);
$viewHelper71->setRenderChildrenClosure($renderChildrenClosure52);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output50 .= $viewHelper71->initializeArgumentsAndRender();

$output50 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments72 = array();
// Rendering Boolean node
$arguments72['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 0);
$arguments72['then'] = NULL;
$arguments72['else'] = NULL;
$renderChildrenClosure73 = function() use ($renderingContext, $self) {
$output74 = '';

$output74 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments75 = array();
$arguments75['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array76 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments77 = array();
$arguments77['key'] = 'forRootLevel';
$arguments77['id'] = NULL;
$arguments77['default'] = NULL;
$arguments77['htmlEscape'] = NULL;
$arguments77['arguments'] = NULL;
$arguments77['extensionName'] = NULL;
$renderChildrenClosure78 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper79 = $self->getViewHelper('$viewHelper79', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper79->setArguments($arguments77);
$viewHelper79->setRenderingContext($renderingContext);
$viewHelper79->setRenderChildrenClosure($renderChildrenClosure78);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array76['0'] = $viewHelper79->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments80 = array();
$output81 = '';

$output81 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output81 .= ' H:i';
$arguments80['format'] = $output81;
$output82 = '';

$output82 .= '@';

$output82 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments80['date'] = $output82;
$renderChildrenClosure83 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper84 = $self->getViewHelper('$viewHelper84', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper84->setArguments($arguments80);
$viewHelper84->setRenderingContext($renderingContext);
$viewHelper84->setRenderChildrenClosure($renderChildrenClosure83);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array76['1'] = $viewHelper84->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments85 = array();
$output86 = '';

$output86 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output86 .= ' H:i';
$arguments85['format'] = $output86;
$output87 = '';

$output87 .= '@';

$output87 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments85['date'] = $output87;
$renderChildrenClosure88 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper89 = $self->getViewHelper('$viewHelper89', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper89->setArguments($arguments85);
$viewHelper89->setRenderingContext($renderingContext);
$viewHelper89->setRenderChildrenClosure($renderChildrenClosure88);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array76['2'] = $viewHelper89->initializeArgumentsAndRender();
$arguments75['arguments'] = $array76;
$arguments75['id'] = NULL;
$arguments75['default'] = NULL;
$arguments75['htmlEscape'] = NULL;
$arguments75['extensionName'] = NULL;
$renderChildrenClosure90 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper91 = $self->getViewHelper('$viewHelper91', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper91->setArguments($arguments75);
$viewHelper91->setRenderingContext($renderingContext);
$viewHelper91->setRenderChildrenClosure($renderChildrenClosure90);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output74 .= $viewHelper91->initializeArgumentsAndRender();

$output74 .= '
							';
return $output74;
};
$viewHelper92 = $self->getViewHelper('$viewHelper92', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper92->setArguments($arguments72);
$viewHelper92->setRenderingContext($renderingContext);
$viewHelper92->setRenderChildrenClosure($renderChildrenClosure73);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output50 .= $viewHelper92->initializeArgumentsAndRender();

$output50 .= '
						';
return $output50;
};
$viewHelper93 = $self->getViewHelper('$viewHelper93', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper93->setArguments($arguments48);
$viewHelper93->setRenderingContext($renderingContext);
$viewHelper93->setRenderChildrenClosure($renderChildrenClosure49);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output47 .= $viewHelper93->initializeArgumentsAndRender();

$output47 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments94 = array();
$renderChildrenClosure95 = function() use ($renderingContext, $self) {
$output96 = '';

$output96 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments97 = array();
$renderChildrenClosure98 = function() use ($renderingContext, $self) {
return '
								Nest view helpers three times:
								1. Feed pid as argument to be.pagePath
								2. Use this as argument for \'forPage\' translate
								3. Use this as argument for \'logForNonPageRelatedActionsOrRootLevelOrPage\' translate
							';
};
$viewHelper99 = $self->getViewHelper('$viewHelper99', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper99->setArguments($arguments97);
$viewHelper99->setRenderingContext($renderingContext);
$viewHelper99->setRenderChildrenClosure($renderChildrenClosure98);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output96 .= $viewHelper99->initializeArgumentsAndRender();

$output96 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments100 = array();
$arguments100['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array101 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments102 = array();
$arguments102['key'] = 'forPage';
// Rendering Boolean node
$arguments102['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
// Rendering Array
$array103 = array();
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$arguments104 = array();
$arguments104['pid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments104['titleLimit'] = 20;
$renderChildrenClosure105 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper106 = $self->getViewHelper('$viewHelper106', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper');
$viewHelper106->setArguments($arguments104);
$viewHelper106->setRenderingContext($renderingContext);
$viewHelper106->setRenderChildrenClosure($renderChildrenClosure105);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$array103['0'] = $viewHelper106->initializeArgumentsAndRender();
$array103['1'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments102['arguments'] = $array103;
$arguments102['id'] = NULL;
$arguments102['default'] = NULL;
$arguments102['extensionName'] = NULL;
$renderChildrenClosure107 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper108 = $self->getViewHelper('$viewHelper108', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper108->setArguments($arguments102);
$viewHelper108->setRenderingContext($renderingContext);
$viewHelper108->setRenderChildrenClosure($renderChildrenClosure107);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array101['0'] = $viewHelper108->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments109 = array();
$output110 = '';

$output110 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output110 .= ' H:i';
$arguments109['format'] = $output110;
$output111 = '';

$output111 .= '@';

$output111 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments109['date'] = $output111;
$renderChildrenClosure112 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper113 = $self->getViewHelper('$viewHelper113', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper113->setArguments($arguments109);
$viewHelper113->setRenderingContext($renderingContext);
$viewHelper113->setRenderChildrenClosure($renderChildrenClosure112);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array101['1'] = $viewHelper113->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments114 = array();
$output115 = '';

$output115 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output115 .= ' H:i';
$arguments114['format'] = $output115;
$output116 = '';

$output116 .= '@';

$output116 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments114['date'] = $output116;
$renderChildrenClosure117 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper118 = $self->getViewHelper('$viewHelper118', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper118->setArguments($arguments114);
$viewHelper118->setRenderingContext($renderingContext);
$viewHelper118->setRenderChildrenClosure($renderChildrenClosure117);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array101['2'] = $viewHelper118->initializeArgumentsAndRender();
$arguments100['arguments'] = $array101;
$arguments100['id'] = NULL;
$arguments100['default'] = NULL;
$arguments100['htmlEscape'] = NULL;
$arguments100['extensionName'] = NULL;
$renderChildrenClosure119 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper120 = $self->getViewHelper('$viewHelper120', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper120->setArguments($arguments100);
$viewHelper120->setRenderingContext($renderingContext);
$viewHelper120->setRenderChildrenClosure($renderChildrenClosure119);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output96 .= $viewHelper120->initializeArgumentsAndRender();

$output96 .= '
						';
return $output96;
};
$viewHelper121 = $self->getViewHelper('$viewHelper121', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper121->setArguments($arguments94);
$viewHelper121->setRenderingContext($renderingContext);
$viewHelper121->setRenderChildrenClosure($renderChildrenClosure95);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output47 .= $viewHelper121->initializeArgumentsAndRender();

$output47 .= '
					';
return $output47;
};
$arguments45['__thenClosure'] = function() use ($renderingContext, $self) {
$output122 = '';

$output122 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments123 = array();
// Rendering Boolean node
$arguments123['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), -1);
$arguments123['then'] = NULL;
$arguments123['else'] = NULL;
$renderChildrenClosure124 = function() use ($renderingContext, $self) {
$output125 = '';

$output125 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments126 = array();
$arguments126['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array127 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments128 = array();
$arguments128['key'] = 'forNonPageRelatedActions';
$arguments128['id'] = NULL;
$arguments128['default'] = NULL;
$arguments128['htmlEscape'] = NULL;
$arguments128['arguments'] = NULL;
$arguments128['extensionName'] = NULL;
$renderChildrenClosure129 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper130 = $self->getViewHelper('$viewHelper130', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper130->setArguments($arguments128);
$viewHelper130->setRenderingContext($renderingContext);
$viewHelper130->setRenderChildrenClosure($renderChildrenClosure129);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array127['0'] = $viewHelper130->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments131 = array();
$output132 = '';

$output132 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output132 .= ' H:i';
$arguments131['format'] = $output132;
$output133 = '';

$output133 .= '@';

$output133 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments131['date'] = $output133;
$renderChildrenClosure134 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper135 = $self->getViewHelper('$viewHelper135', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper135->setArguments($arguments131);
$viewHelper135->setRenderingContext($renderingContext);
$viewHelper135->setRenderChildrenClosure($renderChildrenClosure134);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array127['1'] = $viewHelper135->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments136 = array();
$output137 = '';

$output137 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output137 .= ' H:i';
$arguments136['format'] = $output137;
$output138 = '';

$output138 .= '@';

$output138 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments136['date'] = $output138;
$renderChildrenClosure139 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper140 = $self->getViewHelper('$viewHelper140', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper140->setArguments($arguments136);
$viewHelper140->setRenderingContext($renderingContext);
$viewHelper140->setRenderChildrenClosure($renderChildrenClosure139);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array127['2'] = $viewHelper140->initializeArgumentsAndRender();
$arguments126['arguments'] = $array127;
$arguments126['id'] = NULL;
$arguments126['default'] = NULL;
$arguments126['htmlEscape'] = NULL;
$arguments126['extensionName'] = NULL;
$renderChildrenClosure141 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper142 = $self->getViewHelper('$viewHelper142', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper142->setArguments($arguments126);
$viewHelper142->setRenderingContext($renderingContext);
$viewHelper142->setRenderChildrenClosure($renderChildrenClosure141);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output125 .= $viewHelper142->initializeArgumentsAndRender();

$output125 .= '
							';
return $output125;
};
$viewHelper143 = $self->getViewHelper('$viewHelper143', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper143->setArguments($arguments123);
$viewHelper143->setRenderingContext($renderingContext);
$viewHelper143->setRenderChildrenClosure($renderChildrenClosure124);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output122 .= $viewHelper143->initializeArgumentsAndRender();

$output122 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments144 = array();
// Rendering Boolean node
$arguments144['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 0);
$arguments144['then'] = NULL;
$arguments144['else'] = NULL;
$renderChildrenClosure145 = function() use ($renderingContext, $self) {
$output146 = '';

$output146 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments147 = array();
$arguments147['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array148 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments149 = array();
$arguments149['key'] = 'forRootLevel';
$arguments149['id'] = NULL;
$arguments149['default'] = NULL;
$arguments149['htmlEscape'] = NULL;
$arguments149['arguments'] = NULL;
$arguments149['extensionName'] = NULL;
$renderChildrenClosure150 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper151 = $self->getViewHelper('$viewHelper151', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper151->setArguments($arguments149);
$viewHelper151->setRenderingContext($renderingContext);
$viewHelper151->setRenderChildrenClosure($renderChildrenClosure150);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array148['0'] = $viewHelper151->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments152 = array();
$output153 = '';

$output153 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output153 .= ' H:i';
$arguments152['format'] = $output153;
$output154 = '';

$output154 .= '@';

$output154 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments152['date'] = $output154;
$renderChildrenClosure155 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper156 = $self->getViewHelper('$viewHelper156', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper156->setArguments($arguments152);
$viewHelper156->setRenderingContext($renderingContext);
$viewHelper156->setRenderChildrenClosure($renderChildrenClosure155);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array148['1'] = $viewHelper156->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments157 = array();
$output158 = '';

$output158 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output158 .= ' H:i';
$arguments157['format'] = $output158;
$output159 = '';

$output159 .= '@';

$output159 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments157['date'] = $output159;
$renderChildrenClosure160 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper161 = $self->getViewHelper('$viewHelper161', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper161->setArguments($arguments157);
$viewHelper161->setRenderingContext($renderingContext);
$viewHelper161->setRenderChildrenClosure($renderChildrenClosure160);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array148['2'] = $viewHelper161->initializeArgumentsAndRender();
$arguments147['arguments'] = $array148;
$arguments147['id'] = NULL;
$arguments147['default'] = NULL;
$arguments147['htmlEscape'] = NULL;
$arguments147['extensionName'] = NULL;
$renderChildrenClosure162 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper163 = $self->getViewHelper('$viewHelper163', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper163->setArguments($arguments147);
$viewHelper163->setRenderingContext($renderingContext);
$viewHelper163->setRenderChildrenClosure($renderChildrenClosure162);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output146 .= $viewHelper163->initializeArgumentsAndRender();

$output146 .= '
							';
return $output146;
};
$viewHelper164 = $self->getViewHelper('$viewHelper164', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper164->setArguments($arguments144);
$viewHelper164->setRenderingContext($renderingContext);
$viewHelper164->setRenderChildrenClosure($renderChildrenClosure145);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output122 .= $viewHelper164->initializeArgumentsAndRender();

$output122 .= '
						';
return $output122;
};
$arguments45['__elseClosure'] = function() use ($renderingContext, $self) {
$output165 = '';

$output165 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments166 = array();
$renderChildrenClosure167 = function() use ($renderingContext, $self) {
return '
								Nest view helpers three times:
								1. Feed pid as argument to be.pagePath
								2. Use this as argument for \'forPage\' translate
								3. Use this as argument for \'logForNonPageRelatedActionsOrRootLevelOrPage\' translate
							';
};
$viewHelper168 = $self->getViewHelper('$viewHelper168', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper168->setArguments($arguments166);
$viewHelper168->setRenderingContext($renderingContext);
$viewHelper168->setRenderChildrenClosure($renderChildrenClosure167);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output165 .= $viewHelper168->initializeArgumentsAndRender();

$output165 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments169 = array();
$arguments169['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array170 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments171 = array();
$arguments171['key'] = 'forPage';
// Rendering Boolean node
$arguments171['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
// Rendering Array
$array172 = array();
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$arguments173 = array();
$arguments173['pid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments173['titleLimit'] = 20;
$renderChildrenClosure174 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper175 = $self->getViewHelper('$viewHelper175', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper');
$viewHelper175->setArguments($arguments173);
$viewHelper175->setRenderingContext($renderingContext);
$viewHelper175->setRenderChildrenClosure($renderChildrenClosure174);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$array172['0'] = $viewHelper175->initializeArgumentsAndRender();
$array172['1'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments171['arguments'] = $array172;
$arguments171['id'] = NULL;
$arguments171['default'] = NULL;
$arguments171['extensionName'] = NULL;
$renderChildrenClosure176 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper177 = $self->getViewHelper('$viewHelper177', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper177->setArguments($arguments171);
$viewHelper177->setRenderingContext($renderingContext);
$viewHelper177->setRenderChildrenClosure($renderChildrenClosure176);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array170['0'] = $viewHelper177->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments178 = array();
$output179 = '';

$output179 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output179 .= ' H:i';
$arguments178['format'] = $output179;
$output180 = '';

$output180 .= '@';

$output180 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments178['date'] = $output180;
$renderChildrenClosure181 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper182 = $self->getViewHelper('$viewHelper182', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper182->setArguments($arguments178);
$viewHelper182->setRenderingContext($renderingContext);
$viewHelper182->setRenderChildrenClosure($renderChildrenClosure181);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array170['1'] = $viewHelper182->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments183 = array();
$output184 = '';

$output184 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output184 .= ' H:i';
$arguments183['format'] = $output184;
$output185 = '';

$output185 .= '@';

$output185 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments183['date'] = $output185;
$renderChildrenClosure186 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper187 = $self->getViewHelper('$viewHelper187', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper187->setArguments($arguments183);
$viewHelper187->setRenderingContext($renderingContext);
$viewHelper187->setRenderChildrenClosure($renderChildrenClosure186);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array170['2'] = $viewHelper187->initializeArgumentsAndRender();
$arguments169['arguments'] = $array170;
$arguments169['id'] = NULL;
$arguments169['default'] = NULL;
$arguments169['htmlEscape'] = NULL;
$arguments169['extensionName'] = NULL;
$renderChildrenClosure188 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper189 = $self->getViewHelper('$viewHelper189', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper189->setArguments($arguments169);
$viewHelper189->setRenderingContext($renderingContext);
$viewHelper189->setRenderChildrenClosure($renderChildrenClosure188);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output165 .= $viewHelper189->initializeArgumentsAndRender();

$output165 .= '
						';
return $output165;
};
$viewHelper190 = $self->getViewHelper('$viewHelper190', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper190->setArguments($arguments45);
$viewHelper190->setRenderingContext($renderingContext);
$viewHelper190->setRenderChildrenClosure($renderChildrenClosure46);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output44 .= $viewHelper190->initializeArgumentsAndRender();

$output44 .= '
				';
return $output44;
};
$viewHelper191 = $self->getViewHelper('$viewHelper191', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper191->setArguments($arguments42);
$viewHelper191->setRenderingContext($renderingContext);
$viewHelper191->setRenderChildrenClosure($renderChildrenClosure43);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output41 .= $viewHelper191->initializeArgumentsAndRender();

$output41 .= '
				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments192 = array();
$renderChildrenClosure193 = function() use ($renderingContext, $self) {
$output194 = '';

$output194 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments195 = array();
$arguments195['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array196 = array();
$array196['0'] = '';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments197 = array();
$output198 = '';

$output198 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output198 .= ' H:i';
$arguments197['format'] = $output198;
$output199 = '';

$output199 .= '@';

$output199 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments197['date'] = $output199;
$renderChildrenClosure200 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper201 = $self->getViewHelper('$viewHelper201', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper201->setArguments($arguments197);
$viewHelper201->setRenderingContext($renderingContext);
$viewHelper201->setRenderChildrenClosure($renderChildrenClosure200);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array196['1'] = $viewHelper201->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments202 = array();
$output203 = '';

$output203 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output203 .= ' H:i';
$arguments202['format'] = $output203;
$output204 = '';

$output204 .= '@';

$output204 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments202['date'] = $output204;
$renderChildrenClosure205 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper206 = $self->getViewHelper('$viewHelper206', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper206->setArguments($arguments202);
$viewHelper206->setRenderingContext($renderingContext);
$viewHelper206->setRenderChildrenClosure($renderChildrenClosure205);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array196['2'] = $viewHelper206->initializeArgumentsAndRender();
$arguments195['arguments'] = $array196;
$arguments195['id'] = NULL;
$arguments195['default'] = NULL;
$arguments195['htmlEscape'] = NULL;
$arguments195['extensionName'] = NULL;
$renderChildrenClosure207 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper208 = $self->getViewHelper('$viewHelper208', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper208->setArguments($arguments195);
$viewHelper208->setRenderingContext($renderingContext);
$viewHelper208->setRenderChildrenClosure($renderChildrenClosure207);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output194 .= $viewHelper208->initializeArgumentsAndRender();

$output194 .= '
				';
return $output194;
};
$viewHelper209 = $self->getViewHelper('$viewHelper209', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper209->setArguments($arguments192);
$viewHelper209->setRenderingContext($renderingContext);
$viewHelper209->setRenderChildrenClosure($renderChildrenClosure193);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output41 .= $viewHelper209->initializeArgumentsAndRender();

$output41 .= '
			';
return $output41;
};
$arguments39['__thenClosure'] = function() use ($renderingContext, $self) {
$output210 = '';

$output210 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments211 = array();
// Rendering Boolean node
$arguments211['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('<', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 1);
$arguments211['then'] = NULL;
$arguments211['else'] = NULL;
$renderChildrenClosure212 = function() use ($renderingContext, $self) {
$output213 = '';

$output213 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments214 = array();
$renderChildrenClosure215 = function() use ($renderingContext, $self) {
$output216 = '';

$output216 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments217 = array();
// Rendering Boolean node
$arguments217['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), -1);
$arguments217['then'] = NULL;
$arguments217['else'] = NULL;
$renderChildrenClosure218 = function() use ($renderingContext, $self) {
$output219 = '';

$output219 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments220 = array();
$arguments220['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array221 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments222 = array();
$arguments222['key'] = 'forNonPageRelatedActions';
$arguments222['id'] = NULL;
$arguments222['default'] = NULL;
$arguments222['htmlEscape'] = NULL;
$arguments222['arguments'] = NULL;
$arguments222['extensionName'] = NULL;
$renderChildrenClosure223 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper224 = $self->getViewHelper('$viewHelper224', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper224->setArguments($arguments222);
$viewHelper224->setRenderingContext($renderingContext);
$viewHelper224->setRenderChildrenClosure($renderChildrenClosure223);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array221['0'] = $viewHelper224->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments225 = array();
$output226 = '';

$output226 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output226 .= ' H:i';
$arguments225['format'] = $output226;
$output227 = '';

$output227 .= '@';

$output227 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments225['date'] = $output227;
$renderChildrenClosure228 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper229 = $self->getViewHelper('$viewHelper229', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper229->setArguments($arguments225);
$viewHelper229->setRenderingContext($renderingContext);
$viewHelper229->setRenderChildrenClosure($renderChildrenClosure228);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array221['1'] = $viewHelper229->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments230 = array();
$output231 = '';

$output231 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output231 .= ' H:i';
$arguments230['format'] = $output231;
$output232 = '';

$output232 .= '@';

$output232 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments230['date'] = $output232;
$renderChildrenClosure233 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper234 = $self->getViewHelper('$viewHelper234', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper234->setArguments($arguments230);
$viewHelper234->setRenderingContext($renderingContext);
$viewHelper234->setRenderChildrenClosure($renderChildrenClosure233);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array221['2'] = $viewHelper234->initializeArgumentsAndRender();
$arguments220['arguments'] = $array221;
$arguments220['id'] = NULL;
$arguments220['default'] = NULL;
$arguments220['htmlEscape'] = NULL;
$arguments220['extensionName'] = NULL;
$renderChildrenClosure235 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper236 = $self->getViewHelper('$viewHelper236', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper236->setArguments($arguments220);
$viewHelper236->setRenderingContext($renderingContext);
$viewHelper236->setRenderChildrenClosure($renderChildrenClosure235);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output219 .= $viewHelper236->initializeArgumentsAndRender();

$output219 .= '
							';
return $output219;
};
$viewHelper237 = $self->getViewHelper('$viewHelper237', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper237->setArguments($arguments217);
$viewHelper237->setRenderingContext($renderingContext);
$viewHelper237->setRenderChildrenClosure($renderChildrenClosure218);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output216 .= $viewHelper237->initializeArgumentsAndRender();

$output216 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments238 = array();
// Rendering Boolean node
$arguments238['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 0);
$arguments238['then'] = NULL;
$arguments238['else'] = NULL;
$renderChildrenClosure239 = function() use ($renderingContext, $self) {
$output240 = '';

$output240 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments241 = array();
$arguments241['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array242 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments243 = array();
$arguments243['key'] = 'forRootLevel';
$arguments243['id'] = NULL;
$arguments243['default'] = NULL;
$arguments243['htmlEscape'] = NULL;
$arguments243['arguments'] = NULL;
$arguments243['extensionName'] = NULL;
$renderChildrenClosure244 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper245 = $self->getViewHelper('$viewHelper245', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper245->setArguments($arguments243);
$viewHelper245->setRenderingContext($renderingContext);
$viewHelper245->setRenderChildrenClosure($renderChildrenClosure244);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array242['0'] = $viewHelper245->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments246 = array();
$output247 = '';

$output247 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output247 .= ' H:i';
$arguments246['format'] = $output247;
$output248 = '';

$output248 .= '@';

$output248 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments246['date'] = $output248;
$renderChildrenClosure249 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper250 = $self->getViewHelper('$viewHelper250', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper250->setArguments($arguments246);
$viewHelper250->setRenderingContext($renderingContext);
$viewHelper250->setRenderChildrenClosure($renderChildrenClosure249);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array242['1'] = $viewHelper250->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments251 = array();
$output252 = '';

$output252 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output252 .= ' H:i';
$arguments251['format'] = $output252;
$output253 = '';

$output253 .= '@';

$output253 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments251['date'] = $output253;
$renderChildrenClosure254 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper255 = $self->getViewHelper('$viewHelper255', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper255->setArguments($arguments251);
$viewHelper255->setRenderingContext($renderingContext);
$viewHelper255->setRenderChildrenClosure($renderChildrenClosure254);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array242['2'] = $viewHelper255->initializeArgumentsAndRender();
$arguments241['arguments'] = $array242;
$arguments241['id'] = NULL;
$arguments241['default'] = NULL;
$arguments241['htmlEscape'] = NULL;
$arguments241['extensionName'] = NULL;
$renderChildrenClosure256 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper257 = $self->getViewHelper('$viewHelper257', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper257->setArguments($arguments241);
$viewHelper257->setRenderingContext($renderingContext);
$viewHelper257->setRenderChildrenClosure($renderChildrenClosure256);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output240 .= $viewHelper257->initializeArgumentsAndRender();

$output240 .= '
							';
return $output240;
};
$viewHelper258 = $self->getViewHelper('$viewHelper258', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper258->setArguments($arguments238);
$viewHelper258->setRenderingContext($renderingContext);
$viewHelper258->setRenderChildrenClosure($renderChildrenClosure239);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output216 .= $viewHelper258->initializeArgumentsAndRender();

$output216 .= '
						';
return $output216;
};
$viewHelper259 = $self->getViewHelper('$viewHelper259', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper259->setArguments($arguments214);
$viewHelper259->setRenderingContext($renderingContext);
$viewHelper259->setRenderChildrenClosure($renderChildrenClosure215);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output213 .= $viewHelper259->initializeArgumentsAndRender();

$output213 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments260 = array();
$renderChildrenClosure261 = function() use ($renderingContext, $self) {
$output262 = '';

$output262 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments263 = array();
$renderChildrenClosure264 = function() use ($renderingContext, $self) {
return '
								Nest view helpers three times:
								1. Feed pid as argument to be.pagePath
								2. Use this as argument for \'forPage\' translate
								3. Use this as argument for \'logForNonPageRelatedActionsOrRootLevelOrPage\' translate
							';
};
$viewHelper265 = $self->getViewHelper('$viewHelper265', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper265->setArguments($arguments263);
$viewHelper265->setRenderingContext($renderingContext);
$viewHelper265->setRenderChildrenClosure($renderChildrenClosure264);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output262 .= $viewHelper265->initializeArgumentsAndRender();

$output262 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments266 = array();
$arguments266['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array267 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments268 = array();
$arguments268['key'] = 'forPage';
// Rendering Boolean node
$arguments268['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
// Rendering Array
$array269 = array();
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$arguments270 = array();
$arguments270['pid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments270['titleLimit'] = 20;
$renderChildrenClosure271 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper272 = $self->getViewHelper('$viewHelper272', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper');
$viewHelper272->setArguments($arguments270);
$viewHelper272->setRenderingContext($renderingContext);
$viewHelper272->setRenderChildrenClosure($renderChildrenClosure271);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$array269['0'] = $viewHelper272->initializeArgumentsAndRender();
$array269['1'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments268['arguments'] = $array269;
$arguments268['id'] = NULL;
$arguments268['default'] = NULL;
$arguments268['extensionName'] = NULL;
$renderChildrenClosure273 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper274 = $self->getViewHelper('$viewHelper274', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper274->setArguments($arguments268);
$viewHelper274->setRenderingContext($renderingContext);
$viewHelper274->setRenderChildrenClosure($renderChildrenClosure273);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array267['0'] = $viewHelper274->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments275 = array();
$output276 = '';

$output276 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output276 .= ' H:i';
$arguments275['format'] = $output276;
$output277 = '';

$output277 .= '@';

$output277 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments275['date'] = $output277;
$renderChildrenClosure278 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper279 = $self->getViewHelper('$viewHelper279', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper279->setArguments($arguments275);
$viewHelper279->setRenderingContext($renderingContext);
$viewHelper279->setRenderChildrenClosure($renderChildrenClosure278);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array267['1'] = $viewHelper279->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments280 = array();
$output281 = '';

$output281 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output281 .= ' H:i';
$arguments280['format'] = $output281;
$output282 = '';

$output282 .= '@';

$output282 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments280['date'] = $output282;
$renderChildrenClosure283 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper284 = $self->getViewHelper('$viewHelper284', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper284->setArguments($arguments280);
$viewHelper284->setRenderingContext($renderingContext);
$viewHelper284->setRenderChildrenClosure($renderChildrenClosure283);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array267['2'] = $viewHelper284->initializeArgumentsAndRender();
$arguments266['arguments'] = $array267;
$arguments266['id'] = NULL;
$arguments266['default'] = NULL;
$arguments266['htmlEscape'] = NULL;
$arguments266['extensionName'] = NULL;
$renderChildrenClosure285 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper286 = $self->getViewHelper('$viewHelper286', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper286->setArguments($arguments266);
$viewHelper286->setRenderingContext($renderingContext);
$viewHelper286->setRenderChildrenClosure($renderChildrenClosure285);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output262 .= $viewHelper286->initializeArgumentsAndRender();

$output262 .= '
						';
return $output262;
};
$viewHelper287 = $self->getViewHelper('$viewHelper287', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper287->setArguments($arguments260);
$viewHelper287->setRenderingContext($renderingContext);
$viewHelper287->setRenderChildrenClosure($renderChildrenClosure261);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output213 .= $viewHelper287->initializeArgumentsAndRender();

$output213 .= '
					';
return $output213;
};
$arguments211['__thenClosure'] = function() use ($renderingContext, $self) {
$output288 = '';

$output288 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments289 = array();
// Rendering Boolean node
$arguments289['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), -1);
$arguments289['then'] = NULL;
$arguments289['else'] = NULL;
$renderChildrenClosure290 = function() use ($renderingContext, $self) {
$output291 = '';

$output291 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments292 = array();
$arguments292['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array293 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments294 = array();
$arguments294['key'] = 'forNonPageRelatedActions';
$arguments294['id'] = NULL;
$arguments294['default'] = NULL;
$arguments294['htmlEscape'] = NULL;
$arguments294['arguments'] = NULL;
$arguments294['extensionName'] = NULL;
$renderChildrenClosure295 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper296 = $self->getViewHelper('$viewHelper296', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper296->setArguments($arguments294);
$viewHelper296->setRenderingContext($renderingContext);
$viewHelper296->setRenderChildrenClosure($renderChildrenClosure295);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array293['0'] = $viewHelper296->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments297 = array();
$output298 = '';

$output298 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output298 .= ' H:i';
$arguments297['format'] = $output298;
$output299 = '';

$output299 .= '@';

$output299 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments297['date'] = $output299;
$renderChildrenClosure300 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper301 = $self->getViewHelper('$viewHelper301', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper301->setArguments($arguments297);
$viewHelper301->setRenderingContext($renderingContext);
$viewHelper301->setRenderChildrenClosure($renderChildrenClosure300);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array293['1'] = $viewHelper301->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments302 = array();
$output303 = '';

$output303 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output303 .= ' H:i';
$arguments302['format'] = $output303;
$output304 = '';

$output304 .= '@';

$output304 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments302['date'] = $output304;
$renderChildrenClosure305 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper306 = $self->getViewHelper('$viewHelper306', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper306->setArguments($arguments302);
$viewHelper306->setRenderingContext($renderingContext);
$viewHelper306->setRenderChildrenClosure($renderChildrenClosure305);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array293['2'] = $viewHelper306->initializeArgumentsAndRender();
$arguments292['arguments'] = $array293;
$arguments292['id'] = NULL;
$arguments292['default'] = NULL;
$arguments292['htmlEscape'] = NULL;
$arguments292['extensionName'] = NULL;
$renderChildrenClosure307 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper308 = $self->getViewHelper('$viewHelper308', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper308->setArguments($arguments292);
$viewHelper308->setRenderingContext($renderingContext);
$viewHelper308->setRenderChildrenClosure($renderChildrenClosure307);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output291 .= $viewHelper308->initializeArgumentsAndRender();

$output291 .= '
							';
return $output291;
};
$viewHelper309 = $self->getViewHelper('$viewHelper309', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper309->setArguments($arguments289);
$viewHelper309->setRenderingContext($renderingContext);
$viewHelper309->setRenderChildrenClosure($renderChildrenClosure290);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output288 .= $viewHelper309->initializeArgumentsAndRender();

$output288 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments310 = array();
// Rendering Boolean node
$arguments310['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext), 0);
$arguments310['then'] = NULL;
$arguments310['else'] = NULL;
$renderChildrenClosure311 = function() use ($renderingContext, $self) {
$output312 = '';

$output312 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments313 = array();
$arguments313['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array314 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments315 = array();
$arguments315['key'] = 'forRootLevel';
$arguments315['id'] = NULL;
$arguments315['default'] = NULL;
$arguments315['htmlEscape'] = NULL;
$arguments315['arguments'] = NULL;
$arguments315['extensionName'] = NULL;
$renderChildrenClosure316 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper317 = $self->getViewHelper('$viewHelper317', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper317->setArguments($arguments315);
$viewHelper317->setRenderingContext($renderingContext);
$viewHelper317->setRenderChildrenClosure($renderChildrenClosure316);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array314['0'] = $viewHelper317->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments318 = array();
$output319 = '';

$output319 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output319 .= ' H:i';
$arguments318['format'] = $output319;
$output320 = '';

$output320 .= '@';

$output320 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments318['date'] = $output320;
$renderChildrenClosure321 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper322 = $self->getViewHelper('$viewHelper322', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper322->setArguments($arguments318);
$viewHelper322->setRenderingContext($renderingContext);
$viewHelper322->setRenderChildrenClosure($renderChildrenClosure321);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array314['1'] = $viewHelper322->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments323 = array();
$output324 = '';

$output324 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output324 .= ' H:i';
$arguments323['format'] = $output324;
$output325 = '';

$output325 .= '@';

$output325 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments323['date'] = $output325;
$renderChildrenClosure326 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper327 = $self->getViewHelper('$viewHelper327', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper327->setArguments($arguments323);
$viewHelper327->setRenderingContext($renderingContext);
$viewHelper327->setRenderChildrenClosure($renderChildrenClosure326);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array314['2'] = $viewHelper327->initializeArgumentsAndRender();
$arguments313['arguments'] = $array314;
$arguments313['id'] = NULL;
$arguments313['default'] = NULL;
$arguments313['htmlEscape'] = NULL;
$arguments313['extensionName'] = NULL;
$renderChildrenClosure328 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper329 = $self->getViewHelper('$viewHelper329', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper329->setArguments($arguments313);
$viewHelper329->setRenderingContext($renderingContext);
$viewHelper329->setRenderChildrenClosure($renderChildrenClosure328);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output312 .= $viewHelper329->initializeArgumentsAndRender();

$output312 .= '
							';
return $output312;
};
$viewHelper330 = $self->getViewHelper('$viewHelper330', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper330->setArguments($arguments310);
$viewHelper330->setRenderingContext($renderingContext);
$viewHelper330->setRenderChildrenClosure($renderChildrenClosure311);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output288 .= $viewHelper330->initializeArgumentsAndRender();

$output288 .= '
						';
return $output288;
};
$arguments211['__elseClosure'] = function() use ($renderingContext, $self) {
$output331 = '';

$output331 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments332 = array();
$renderChildrenClosure333 = function() use ($renderingContext, $self) {
return '
								Nest view helpers three times:
								1. Feed pid as argument to be.pagePath
								2. Use this as argument for \'forPage\' translate
								3. Use this as argument for \'logForNonPageRelatedActionsOrRootLevelOrPage\' translate
							';
};
$viewHelper334 = $self->getViewHelper('$viewHelper334', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper334->setArguments($arguments332);
$viewHelper334->setRenderingContext($renderingContext);
$viewHelper334->setRenderChildrenClosure($renderChildrenClosure333);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output331 .= $viewHelper334->initializeArgumentsAndRender();

$output331 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments335 = array();
$arguments335['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array336 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments337 = array();
$arguments337['key'] = 'forPage';
// Rendering Boolean node
$arguments337['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
// Rendering Array
$array338 = array();
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$arguments339 = array();
$arguments339['pid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments339['titleLimit'] = 20;
$renderChildrenClosure340 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper341 = $self->getViewHelper('$viewHelper341', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper');
$viewHelper341->setArguments($arguments339);
$viewHelper341->setRenderingContext($renderingContext);
$viewHelper341->setRenderChildrenClosure($renderChildrenClosure340);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\PagePathViewHelper
$array338['0'] = $viewHelper341->initializeArgumentsAndRender();
$array338['1'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pid', $renderingContext);
$arguments337['arguments'] = $array338;
$arguments337['id'] = NULL;
$arguments337['default'] = NULL;
$arguments337['extensionName'] = NULL;
$renderChildrenClosure342 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper343 = $self->getViewHelper('$viewHelper343', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper343->setArguments($arguments337);
$viewHelper343->setRenderingContext($renderingContext);
$viewHelper343->setRenderChildrenClosure($renderChildrenClosure342);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$array336['0'] = $viewHelper343->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments344 = array();
$output345 = '';

$output345 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output345 .= ' H:i';
$arguments344['format'] = $output345;
$output346 = '';

$output346 .= '@';

$output346 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments344['date'] = $output346;
$renderChildrenClosure347 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper348 = $self->getViewHelper('$viewHelper348', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper348->setArguments($arguments344);
$viewHelper348->setRenderingContext($renderingContext);
$viewHelper348->setRenderChildrenClosure($renderChildrenClosure347);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array336['1'] = $viewHelper348->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments349 = array();
$output350 = '';

$output350 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output350 .= ' H:i';
$arguments349['format'] = $output350;
$output351 = '';

$output351 .= '@';

$output351 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments349['date'] = $output351;
$renderChildrenClosure352 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper353 = $self->getViewHelper('$viewHelper353', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper353->setArguments($arguments349);
$viewHelper353->setRenderingContext($renderingContext);
$viewHelper353->setRenderChildrenClosure($renderChildrenClosure352);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array336['2'] = $viewHelper353->initializeArgumentsAndRender();
$arguments335['arguments'] = $array336;
$arguments335['id'] = NULL;
$arguments335['default'] = NULL;
$arguments335['htmlEscape'] = NULL;
$arguments335['extensionName'] = NULL;
$renderChildrenClosure354 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper355 = $self->getViewHelper('$viewHelper355', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper355->setArguments($arguments335);
$viewHelper355->setRenderingContext($renderingContext);
$viewHelper355->setRenderChildrenClosure($renderChildrenClosure354);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output331 .= $viewHelper355->initializeArgumentsAndRender();

$output331 .= '
						';
return $output331;
};
$viewHelper356 = $self->getViewHelper('$viewHelper356', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper356->setArguments($arguments211);
$viewHelper356->setRenderingContext($renderingContext);
$viewHelper356->setRenderChildrenClosure($renderChildrenClosure212);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output210 .= $viewHelper356->initializeArgumentsAndRender();

$output210 .= '
				';
return $output210;
};
$arguments39['__elseClosure'] = function() use ($renderingContext, $self) {
$output357 = '';

$output357 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments358 = array();
$arguments358['key'] = 'logForNonPageRelatedActionsOrRootLevelOrPage';
// Rendering Array
$array359 = array();
$array359['0'] = '';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments360 = array();
$output361 = '';

$output361 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output361 .= ' H:i';
$arguments360['format'] = $output361;
$output362 = '';

$output362 .= '@';

$output362 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.startTimestamp', $renderingContext);
$arguments360['date'] = $output362;
$renderChildrenClosure363 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper364 = $self->getViewHelper('$viewHelper364', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper364->setArguments($arguments360);
$viewHelper364->setRenderingContext($renderingContext);
$viewHelper364->setRenderChildrenClosure($renderChildrenClosure363);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array359['1'] = $viewHelper364->initializeArgumentsAndRender();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments365 = array();
$output366 = '';

$output366 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output366 .= ' H:i';
$arguments365['format'] = $output366;
$output367 = '';

$output367 .= '@';

$output367 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.endTimestamp', $renderingContext);
$arguments365['date'] = $output367;
$renderChildrenClosure368 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper369 = $self->getViewHelper('$viewHelper369', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper369->setArguments($arguments365);
$viewHelper369->setRenderingContext($renderingContext);
$viewHelper369->setRenderChildrenClosure($renderChildrenClosure368);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$array359['2'] = $viewHelper369->initializeArgumentsAndRender();
$arguments358['arguments'] = $array359;
$arguments358['id'] = NULL;
$arguments358['default'] = NULL;
$arguments358['htmlEscape'] = NULL;
$arguments358['extensionName'] = NULL;
$renderChildrenClosure370 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper371 = $self->getViewHelper('$viewHelper371', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper371->setArguments($arguments358);
$viewHelper371->setRenderingContext($renderingContext);
$viewHelper371->setRenderChildrenClosure($renderChildrenClosure370);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output357 .= $viewHelper371->initializeArgumentsAndRender();

$output357 .= '
				';
return $output357;
};
$viewHelper372 = $self->getViewHelper('$viewHelper372', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper372->setArguments($arguments39);
$viewHelper372->setRenderingContext($renderingContext);
$viewHelper372->setRenderChildrenClosure($renderChildrenClosure40);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output38 .= $viewHelper372->initializeArgumentsAndRender();

$output38 .= '
		</h2>
		';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper
$arguments373 = array();
$arguments373['each'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pidEntry', $renderingContext);
$arguments373['as'] = 'day';
$arguments373['key'] = 'dayTimestamp';
$arguments373['reverse'] = false;
$arguments373['iteration'] = NULL;
$renderChildrenClosure374 = function() use ($renderingContext, $self) {
$output375 = '';

$output375 .= '
			<h3>
				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments376 = array();
$arguments376['format'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);
$arguments376['date'] = NULL;
$renderChildrenClosure377 = function() use ($renderingContext, $self) {
$output378 = '';

$output378 .= '@';

$output378 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'dayTimestamp', $renderingContext);
return $output378;
};
$viewHelper379 = $self->getViewHelper('$viewHelper379', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper379->setArguments($arguments376);
$viewHelper379->setRenderingContext($renderingContext);
$viewHelper379->setRenderChildrenClosure($renderChildrenClosure377);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper

$output375 .= $viewHelper379->initializeArgumentsAndRender();

$output375 .= '
			</h3>

			<table class="t3-table">
				<thead>
					<tr>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments380 = array();
$arguments380['key'] = 'chLog_l_error';
$arguments380['id'] = NULL;
$arguments380['default'] = NULL;
$arguments380['htmlEscape'] = NULL;
$arguments380['arguments'] = NULL;
$arguments380['extensionName'] = NULL;
$renderChildrenClosure381 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper382 = $self->getViewHelper('$viewHelper382', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper382->setArguments($arguments380);
$viewHelper382->setRenderingContext($renderingContext);
$viewHelper382->setRenderChildrenClosure($renderChildrenClosure381);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output375 .= $viewHelper382->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments383 = array();
$arguments383['key'] = 'chLog_l_time';
$arguments383['id'] = NULL;
$arguments383['default'] = NULL;
$arguments383['htmlEscape'] = NULL;
$arguments383['arguments'] = NULL;
$arguments383['extensionName'] = NULL;
$renderChildrenClosure384 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper385 = $self->getViewHelper('$viewHelper385', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper385->setArguments($arguments383);
$viewHelper385->setRenderingContext($renderingContext);
$viewHelper385->setRenderChildrenClosure($renderChildrenClosure384);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output375 .= $viewHelper385->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments386 = array();
$arguments386['key'] = 'chLog_l_user';
$arguments386['id'] = NULL;
$arguments386['default'] = NULL;
$arguments386['htmlEscape'] = NULL;
$arguments386['arguments'] = NULL;
$arguments386['extensionName'] = NULL;
$renderChildrenClosure387 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper388 = $self->getViewHelper('$viewHelper388', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper388->setArguments($arguments386);
$viewHelper388->setRenderingContext($renderingContext);
$viewHelper388->setRenderChildrenClosure($renderChildrenClosure387);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output375 .= $viewHelper388->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments389 = array();
// Rendering Boolean node
$arguments389['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.isInPageContext', $renderingContext));
$arguments389['then'] = NULL;
$arguments389['else'] = NULL;
$renderChildrenClosure390 = function() use ($renderingContext, $self) {
$output391 = '';

$output391 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments392 = array();
$renderChildrenClosure393 = function() use ($renderingContext, $self) {
$output394 = '';

$output394 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments395 = array();
$arguments395['key'] = 'chLog_l_table';
$arguments395['id'] = NULL;
$arguments395['default'] = NULL;
$arguments395['htmlEscape'] = NULL;
$arguments395['arguments'] = NULL;
$arguments395['extensionName'] = NULL;
$renderChildrenClosure396 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper397 = $self->getViewHelper('$viewHelper397', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper397->setArguments($arguments395);
$viewHelper397->setRenderingContext($renderingContext);
$viewHelper397->setRenderChildrenClosure($renderChildrenClosure396);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output394 .= $viewHelper397->initializeArgumentsAndRender();

$output394 .= '
									';
return $output394;
};
$viewHelper398 = $self->getViewHelper('$viewHelper398', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper398->setArguments($arguments392);
$viewHelper398->setRenderingContext($renderingContext);
$viewHelper398->setRenderChildrenClosure($renderChildrenClosure393);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output391 .= $viewHelper398->initializeArgumentsAndRender();

$output391 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments399 = array();
$renderChildrenClosure400 = function() use ($renderingContext, $self) {
$output401 = '';

$output401 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments402 = array();
$arguments402['key'] = 'chLog_l_types';
$arguments402['id'] = NULL;
$arguments402['default'] = NULL;
$arguments402['htmlEscape'] = NULL;
$arguments402['arguments'] = NULL;
$arguments402['extensionName'] = NULL;
$renderChildrenClosure403 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper404 = $self->getViewHelper('$viewHelper404', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper404->setArguments($arguments402);
$viewHelper404->setRenderingContext($renderingContext);
$viewHelper404->setRenderChildrenClosure($renderChildrenClosure403);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output401 .= $viewHelper404->initializeArgumentsAndRender();

$output401 .= '
									';
return $output401;
};
$viewHelper405 = $self->getViewHelper('$viewHelper405', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper405->setArguments($arguments399);
$viewHelper405->setRenderingContext($renderingContext);
$viewHelper405->setRenderChildrenClosure($renderChildrenClosure400);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output391 .= $viewHelper405->initializeArgumentsAndRender();

$output391 .= '
								';
return $output391;
};
$arguments389['__thenClosure'] = function() use ($renderingContext, $self) {
$output406 = '';

$output406 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments407 = array();
$arguments407['key'] = 'chLog_l_table';
$arguments407['id'] = NULL;
$arguments407['default'] = NULL;
$arguments407['htmlEscape'] = NULL;
$arguments407['arguments'] = NULL;
$arguments407['extensionName'] = NULL;
$renderChildrenClosure408 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper409 = $self->getViewHelper('$viewHelper409', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper409->setArguments($arguments407);
$viewHelper409->setRenderingContext($renderingContext);
$viewHelper409->setRenderChildrenClosure($renderChildrenClosure408);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output406 .= $viewHelper409->initializeArgumentsAndRender();

$output406 .= '
									';
return $output406;
};
$arguments389['__elseClosure'] = function() use ($renderingContext, $self) {
$output410 = '';

$output410 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments411 = array();
$arguments411['key'] = 'chLog_l_types';
$arguments411['id'] = NULL;
$arguments411['default'] = NULL;
$arguments411['htmlEscape'] = NULL;
$arguments411['arguments'] = NULL;
$arguments411['extensionName'] = NULL;
$renderChildrenClosure412 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper413 = $self->getViewHelper('$viewHelper413', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper413->setArguments($arguments411);
$viewHelper413->setRenderingContext($renderingContext);
$viewHelper413->setRenderChildrenClosure($renderChildrenClosure412);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output410 .= $viewHelper413->initializeArgumentsAndRender();

$output410 .= '
									';
return $output410;
};
$viewHelper414 = $self->getViewHelper('$viewHelper414', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper414->setArguments($arguments389);
$viewHelper414->setRenderingContext($renderingContext);
$viewHelper414->setRenderChildrenClosure($renderChildrenClosure390);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output375 .= $viewHelper414->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments415 = array();
$arguments415['key'] = 'chLog_l_action';
$arguments415['id'] = NULL;
$arguments415['default'] = NULL;
$arguments415['htmlEscape'] = NULL;
$arguments415['arguments'] = NULL;
$arguments415['extensionName'] = NULL;
$renderChildrenClosure416 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper417 = $self->getViewHelper('$viewHelper417', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper417->setArguments($arguments415);
$viewHelper417->setRenderingContext($renderingContext);
$viewHelper417->setRenderChildrenClosure($renderChildrenClosure416);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output375 .= $viewHelper417->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
						<th valign="top">
							<strong>
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments418 = array();
$arguments418['key'] = 'chLog_l_details';
$arguments418['id'] = NULL;
$arguments418['default'] = NULL;
$arguments418['htmlEscape'] = NULL;
$arguments418['arguments'] = NULL;
$arguments418['extensionName'] = NULL;
$renderChildrenClosure419 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper420 = $self->getViewHelper('$viewHelper420', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper420->setArguments($arguments418);
$viewHelper420->setRenderingContext($renderingContext);
$viewHelper420->setRenderChildrenClosure($renderChildrenClosure419);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output375 .= $viewHelper420->initializeArgumentsAndRender();

$output375 .= '
							</strong>
						</th>
						<th><img src="clear.gif" width="10" height="1" alt="" /></th>
					</tr>
				</thead>
				<tbody>
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper
$arguments421 = array();
$arguments421['each'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'day', $renderingContext);
$arguments421['as'] = 'logItem';
$arguments421['key'] = '';
$arguments421['reverse'] = false;
$arguments421['iteration'] = NULL;
$renderChildrenClosure422 = function() use ($renderingContext, $self) {
$output423 = '';

$output423 .= '
						<tr>
							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\ErrorIconViewHelper
$arguments424 = array();
$arguments424['errorNumber'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.error', $renderingContext);
$renderChildrenClosure425 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper426 = $self->getViewHelper('$viewHelper426', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\ErrorIconViewHelper');
$viewHelper426->setArguments($arguments424);
$viewHelper426->setRenderingContext($renderingContext);
$viewHelper426->setRenderChildrenClosure($renderChildrenClosure425);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\ErrorIconViewHelper

$output423 .= $viewHelper426->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>

							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments427 = array();
$arguments427['format'] = 'H:i:s';
$arguments427['date'] = NULL;
$renderChildrenClosure428 = function() use ($renderingContext, $self) {
$output429 = '';

$output429 .= '@';

$output429 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.tstamp', $renderingContext);
return $output429;
};
$viewHelper430 = $self->getViewHelper('$viewHelper430', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper430->setArguments($arguments427);
$viewHelper430->setRenderingContext($renderingContext);
$viewHelper430->setRenderChildrenClosure($renderChildrenClosure428);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper

$output423 .= $viewHelper430->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>

							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments431 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
$arguments432 = array();
$arguments432['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.backendUserUid', $renderingContext);
$renderChildrenClosure433 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper434 = $self->getViewHelper('$viewHelper434', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper');
$viewHelper434->setArguments($arguments432);
$viewHelper434->setRenderingContext($renderingContext);
$viewHelper434->setRenderChildrenClosure($renderChildrenClosure433);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
$arguments431['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper434->initializeArgumentsAndRender());
$arguments431['then'] = NULL;
$arguments431['else'] = NULL;
$renderChildrenClosure435 = function() use ($renderingContext, $self) {
$output436 = '';

$output436 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments437 = array();
$renderChildrenClosure438 = function() use ($renderingContext, $self) {
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
$arguments439 = array();
$arguments439['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.backendUserUid', $renderingContext);
$renderChildrenClosure440 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper441 = $self->getViewHelper('$viewHelper441', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper');
$viewHelper441->setArguments($arguments439);
$viewHelper441->setRenderingContext($renderingContext);
$viewHelper441->setRenderChildrenClosure($renderChildrenClosure440);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
return $viewHelper441->initializeArgumentsAndRender();
};
$viewHelper442 = $self->getViewHelper('$viewHelper442', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper442->setArguments($arguments437);
$viewHelper442->setRenderingContext($renderingContext);
$viewHelper442->setRenderChildrenClosure($renderChildrenClosure438);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output436 .= $viewHelper442->initializeArgumentsAndRender();

$output436 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments443 = array();
$renderChildrenClosure444 = function() use ($renderingContext, $self) {
$output445 = '';

$output445 .= '[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments446 = array();
$arguments446['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.backendUserUid', $renderingContext);
$arguments446['keepQuotes'] = false;
$arguments446['encoding'] = NULL;
$arguments446['doubleEncode'] = true;
$renderChildrenClosure447 = function() use ($renderingContext, $self) {
return NULL;
};
$value448 = ($arguments446['value'] !== NULL ? $arguments446['value'] : $renderChildrenClosure447());

$output445 .= (!is_string($value448) ? $value448 : htmlspecialchars($value448, ($arguments446['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments446['encoding'] !== NULL ? $arguments446['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments446['doubleEncode']));

$output445 .= ']';
return $output445;
};
$viewHelper449 = $self->getViewHelper('$viewHelper449', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper449->setArguments($arguments443);
$viewHelper449->setRenderingContext($renderingContext);
$viewHelper449->setRenderChildrenClosure($renderChildrenClosure444);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output436 .= $viewHelper449->initializeArgumentsAndRender();

$output436 .= '
								';
return $output436;
};
$arguments431['__thenClosure'] = function() use ($renderingContext, $self) {
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
$arguments450 = array();
$arguments450['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.backendUserUid', $renderingContext);
$renderChildrenClosure451 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper452 = $self->getViewHelper('$viewHelper452', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper');
$viewHelper452->setArguments($arguments450);
$viewHelper452->setRenderingContext($renderingContext);
$viewHelper452->setRenderChildrenClosure($renderChildrenClosure451);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\UsernameViewHelper
return $viewHelper452->initializeArgumentsAndRender();
};
$arguments431['__elseClosure'] = function() use ($renderingContext, $self) {
$output453 = '';

$output453 .= '[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments454 = array();
$arguments454['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.backendUserUid', $renderingContext);
$arguments454['keepQuotes'] = false;
$arguments454['encoding'] = NULL;
$arguments454['doubleEncode'] = true;
$renderChildrenClosure455 = function() use ($renderingContext, $self) {
return NULL;
};
$value456 = ($arguments454['value'] !== NULL ? $arguments454['value'] : $renderChildrenClosure455());

$output453 .= (!is_string($value456) ? $value456 : htmlspecialchars($value456, ($arguments454['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments454['encoding'] !== NULL ? $arguments454['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments454['doubleEncode']));

$output453 .= ']';
return $output453;
};
$viewHelper457 = $self->getViewHelper('$viewHelper457', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper457->setArguments($arguments431);
$viewHelper457->setRenderingContext($renderingContext);
$viewHelper457->setRenderChildrenClosure($renderChildrenClosure435);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output423 .= $viewHelper457->initializeArgumentsAndRender();

$output423 .= '@';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments458 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
$arguments459 = array();
$arguments459['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.workspaceUid', $renderingContext);
$renderChildrenClosure460 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper461 = $self->getViewHelper('$viewHelper461', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper');
$viewHelper461->setArguments($arguments459);
$viewHelper461->setRenderingContext($renderingContext);
$viewHelper461->setRenderChildrenClosure($renderChildrenClosure460);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
$arguments458['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper461->initializeArgumentsAndRender());
$arguments458['then'] = NULL;
$arguments458['else'] = NULL;
$renderChildrenClosure462 = function() use ($renderingContext, $self) {
$output463 = '';

$output463 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments464 = array();
$renderChildrenClosure465 = function() use ($renderingContext, $self) {
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
$arguments466 = array();
$arguments466['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.workspaceUid', $renderingContext);
$renderChildrenClosure467 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper468 = $self->getViewHelper('$viewHelper468', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper');
$viewHelper468->setArguments($arguments466);
$viewHelper468->setRenderingContext($renderingContext);
$viewHelper468->setRenderChildrenClosure($renderChildrenClosure467);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
return $viewHelper468->initializeArgumentsAndRender();
};
$viewHelper469 = $self->getViewHelper('$viewHelper469', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper469->setArguments($arguments464);
$viewHelper469->setRenderingContext($renderingContext);
$viewHelper469->setRenderChildrenClosure($renderChildrenClosure465);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output463 .= $viewHelper469->initializeArgumentsAndRender();

$output463 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments470 = array();
$renderChildrenClosure471 = function() use ($renderingContext, $self) {
$output472 = '';

$output472 .= '[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments473 = array();
$arguments473['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.workspaceUid', $renderingContext);
$arguments473['keepQuotes'] = false;
$arguments473['encoding'] = NULL;
$arguments473['doubleEncode'] = true;
$renderChildrenClosure474 = function() use ($renderingContext, $self) {
return NULL;
};
$value475 = ($arguments473['value'] !== NULL ? $arguments473['value'] : $renderChildrenClosure474());

$output472 .= (!is_string($value475) ? $value475 : htmlspecialchars($value475, ($arguments473['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments473['encoding'] !== NULL ? $arguments473['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments473['doubleEncode']));

$output472 .= ']';
return $output472;
};
$viewHelper476 = $self->getViewHelper('$viewHelper476', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper476->setArguments($arguments470);
$viewHelper476->setRenderingContext($renderingContext);
$viewHelper476->setRenderChildrenClosure($renderChildrenClosure471);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output463 .= $viewHelper476->initializeArgumentsAndRender();

$output463 .= '
								';
return $output463;
};
$arguments458['__thenClosure'] = function() use ($renderingContext, $self) {
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
$arguments477 = array();
$arguments477['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.workspaceUid', $renderingContext);
$renderChildrenClosure478 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper479 = $self->getViewHelper('$viewHelper479', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper');
$viewHelper479->setArguments($arguments477);
$viewHelper479->setRenderingContext($renderingContext);
$viewHelper479->setRenderChildrenClosure($renderChildrenClosure478);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\WorkspaceTitleViewHelper
return $viewHelper479->initializeArgumentsAndRender();
};
$arguments458['__elseClosure'] = function() use ($renderingContext, $self) {
$output480 = '';

$output480 .= '[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments481 = array();
$arguments481['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.workspaceUid', $renderingContext);
$arguments481['keepQuotes'] = false;
$arguments481['encoding'] = NULL;
$arguments481['doubleEncode'] = true;
$renderChildrenClosure482 = function() use ($renderingContext, $self) {
return NULL;
};
$value483 = ($arguments481['value'] !== NULL ? $arguments481['value'] : $renderChildrenClosure482());

$output480 .= (!is_string($value483) ? $value483 : htmlspecialchars($value483, ($arguments481['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments481['encoding'] !== NULL ? $arguments481['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments481['doubleEncode']));

$output480 .= ']';
return $output480;
};
$viewHelper484 = $self->getViewHelper('$viewHelper484', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper484->setArguments($arguments458);
$viewHelper484->setRenderingContext($renderingContext);
$viewHelper484->setRenderChildrenClosure($renderChildrenClosure462);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output423 .= $viewHelper484->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>

							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments485 = array();
// Rendering Boolean node
$arguments485['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.isInPageContext', $renderingContext));
$arguments485['then'] = NULL;
$arguments485['else'] = NULL;
$renderChildrenClosure486 = function() use ($renderingContext, $self) {
$output487 = '';

$output487 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments488 = array();
$renderChildrenClosure489 = function() use ($renderingContext, $self) {
$output490 = '';

$output490 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments491 = array();
$arguments491['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.tableName', $renderingContext);
$arguments491['keepQuotes'] = false;
$arguments491['encoding'] = NULL;
$arguments491['doubleEncode'] = true;
$renderChildrenClosure492 = function() use ($renderingContext, $self) {
return NULL;
};
$value493 = ($arguments491['value'] !== NULL ? $arguments491['value'] : $renderChildrenClosure492());

$output490 .= (!is_string($value493) ? $value493 : htmlspecialchars($value493, ($arguments491['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments491['encoding'] !== NULL ? $arguments491['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments491['doubleEncode']));

$output490 .= '
									';
return $output490;
};
$viewHelper494 = $self->getViewHelper('$viewHelper494', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper494->setArguments($arguments488);
$viewHelper494->setRenderingContext($renderingContext);
$viewHelper494->setRenderChildrenClosure($renderChildrenClosure489);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output487 .= $viewHelper494->initializeArgumentsAndRender();

$output487 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments495 = array();
$renderChildrenClosure496 = function() use ($renderingContext, $self) {
$output497 = '';

$output497 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments498 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments499 = array();
$output500 = '';

$output500 .= 'type_';

$output500 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments499['key'] = $output500;
$arguments499['id'] = NULL;
$arguments499['default'] = NULL;
$arguments499['htmlEscape'] = NULL;
$arguments499['arguments'] = NULL;
$arguments499['extensionName'] = NULL;
$renderChildrenClosure501 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper502 = $self->getViewHelper('$viewHelper502', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper502->setArguments($arguments499);
$viewHelper502->setRenderingContext($renderingContext);
$viewHelper502->setRenderChildrenClosure($renderChildrenClosure501);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments498['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper502->initializeArgumentsAndRender());
$arguments498['then'] = NULL;
$arguments498['else'] = NULL;
$renderChildrenClosure503 = function() use ($renderingContext, $self) {
$output504 = '';

$output504 .= '
											';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments505 = array();
$renderChildrenClosure506 = function() use ($renderingContext, $self) {
$output507 = '';

$output507 .= '
												';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments508 = array();
$output509 = '';

$output509 .= 'type_';

$output509 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments508['key'] = $output509;
$arguments508['id'] = NULL;
$arguments508['default'] = NULL;
$arguments508['htmlEscape'] = NULL;
$arguments508['arguments'] = NULL;
$arguments508['extensionName'] = NULL;
$renderChildrenClosure510 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper511 = $self->getViewHelper('$viewHelper511', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper511->setArguments($arguments508);
$viewHelper511->setRenderingContext($renderingContext);
$viewHelper511->setRenderChildrenClosure($renderChildrenClosure510);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output507 .= $viewHelper511->initializeArgumentsAndRender();

$output507 .= '
											';
return $output507;
};
$viewHelper512 = $self->getViewHelper('$viewHelper512', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper512->setArguments($arguments505);
$viewHelper512->setRenderingContext($renderingContext);
$viewHelper512->setRenderChildrenClosure($renderChildrenClosure506);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output504 .= $viewHelper512->initializeArgumentsAndRender();

$output504 .= '
											';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments513 = array();
$renderChildrenClosure514 = function() use ($renderingContext, $self) {
$output515 = '';

$output515 .= '
												[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments516 = array();
$arguments516['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments516['keepQuotes'] = false;
$arguments516['encoding'] = NULL;
$arguments516['doubleEncode'] = true;
$renderChildrenClosure517 = function() use ($renderingContext, $self) {
return NULL;
};
$value518 = ($arguments516['value'] !== NULL ? $arguments516['value'] : $renderChildrenClosure517());

$output515 .= (!is_string($value518) ? $value518 : htmlspecialchars($value518, ($arguments516['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments516['encoding'] !== NULL ? $arguments516['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments516['doubleEncode']));

$output515 .= ']
											';
return $output515;
};
$viewHelper519 = $self->getViewHelper('$viewHelper519', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper519->setArguments($arguments513);
$viewHelper519->setRenderingContext($renderingContext);
$viewHelper519->setRenderChildrenClosure($renderChildrenClosure514);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output504 .= $viewHelper519->initializeArgumentsAndRender();

$output504 .= '
										';
return $output504;
};
$arguments498['__thenClosure'] = function() use ($renderingContext, $self) {
$output520 = '';

$output520 .= '
												';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments521 = array();
$output522 = '';

$output522 .= 'type_';

$output522 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments521['key'] = $output522;
$arguments521['id'] = NULL;
$arguments521['default'] = NULL;
$arguments521['htmlEscape'] = NULL;
$arguments521['arguments'] = NULL;
$arguments521['extensionName'] = NULL;
$renderChildrenClosure523 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper524 = $self->getViewHelper('$viewHelper524', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper524->setArguments($arguments521);
$viewHelper524->setRenderingContext($renderingContext);
$viewHelper524->setRenderChildrenClosure($renderChildrenClosure523);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output520 .= $viewHelper524->initializeArgumentsAndRender();

$output520 .= '
											';
return $output520;
};
$arguments498['__elseClosure'] = function() use ($renderingContext, $self) {
$output525 = '';

$output525 .= '
												[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments526 = array();
$arguments526['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments526['keepQuotes'] = false;
$arguments526['encoding'] = NULL;
$arguments526['doubleEncode'] = true;
$renderChildrenClosure527 = function() use ($renderingContext, $self) {
return NULL;
};
$value528 = ($arguments526['value'] !== NULL ? $arguments526['value'] : $renderChildrenClosure527());

$output525 .= (!is_string($value528) ? $value528 : htmlspecialchars($value528, ($arguments526['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments526['encoding'] !== NULL ? $arguments526['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments526['doubleEncode']));

$output525 .= ']
											';
return $output525;
};
$viewHelper529 = $self->getViewHelper('$viewHelper529', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper529->setArguments($arguments498);
$viewHelper529->setRenderingContext($renderingContext);
$viewHelper529->setRenderChildrenClosure($renderChildrenClosure503);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output497 .= $viewHelper529->initializeArgumentsAndRender();

$output497 .= '
									';
return $output497;
};
$viewHelper530 = $self->getViewHelper('$viewHelper530', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper530->setArguments($arguments495);
$viewHelper530->setRenderingContext($renderingContext);
$viewHelper530->setRenderChildrenClosure($renderChildrenClosure496);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output487 .= $viewHelper530->initializeArgumentsAndRender();

$output487 .= '
								';
return $output487;
};
$arguments485['__thenClosure'] = function() use ($renderingContext, $self) {
$output531 = '';

$output531 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments532 = array();
$arguments532['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.tableName', $renderingContext);
$arguments532['keepQuotes'] = false;
$arguments532['encoding'] = NULL;
$arguments532['doubleEncode'] = true;
$renderChildrenClosure533 = function() use ($renderingContext, $self) {
return NULL;
};
$value534 = ($arguments532['value'] !== NULL ? $arguments532['value'] : $renderChildrenClosure533());

$output531 .= (!is_string($value534) ? $value534 : htmlspecialchars($value534, ($arguments532['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments532['encoding'] !== NULL ? $arguments532['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments532['doubleEncode']));

$output531 .= '
									';
return $output531;
};
$arguments485['__elseClosure'] = function() use ($renderingContext, $self) {
$output535 = '';

$output535 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments536 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments537 = array();
$output538 = '';

$output538 .= 'type_';

$output538 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments537['key'] = $output538;
$arguments537['id'] = NULL;
$arguments537['default'] = NULL;
$arguments537['htmlEscape'] = NULL;
$arguments537['arguments'] = NULL;
$arguments537['extensionName'] = NULL;
$renderChildrenClosure539 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper540 = $self->getViewHelper('$viewHelper540', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper540->setArguments($arguments537);
$viewHelper540->setRenderingContext($renderingContext);
$viewHelper540->setRenderChildrenClosure($renderChildrenClosure539);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments536['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper540->initializeArgumentsAndRender());
$arguments536['then'] = NULL;
$arguments536['else'] = NULL;
$renderChildrenClosure541 = function() use ($renderingContext, $self) {
$output542 = '';

$output542 .= '
											';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments543 = array();
$renderChildrenClosure544 = function() use ($renderingContext, $self) {
$output545 = '';

$output545 .= '
												';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments546 = array();
$output547 = '';

$output547 .= 'type_';

$output547 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments546['key'] = $output547;
$arguments546['id'] = NULL;
$arguments546['default'] = NULL;
$arguments546['htmlEscape'] = NULL;
$arguments546['arguments'] = NULL;
$arguments546['extensionName'] = NULL;
$renderChildrenClosure548 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper549 = $self->getViewHelper('$viewHelper549', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper549->setArguments($arguments546);
$viewHelper549->setRenderingContext($renderingContext);
$viewHelper549->setRenderChildrenClosure($renderChildrenClosure548);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output545 .= $viewHelper549->initializeArgumentsAndRender();

$output545 .= '
											';
return $output545;
};
$viewHelper550 = $self->getViewHelper('$viewHelper550', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper550->setArguments($arguments543);
$viewHelper550->setRenderingContext($renderingContext);
$viewHelper550->setRenderChildrenClosure($renderChildrenClosure544);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output542 .= $viewHelper550->initializeArgumentsAndRender();

$output542 .= '
											';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments551 = array();
$renderChildrenClosure552 = function() use ($renderingContext, $self) {
$output553 = '';

$output553 .= '
												[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments554 = array();
$arguments554['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments554['keepQuotes'] = false;
$arguments554['encoding'] = NULL;
$arguments554['doubleEncode'] = true;
$renderChildrenClosure555 = function() use ($renderingContext, $self) {
return NULL;
};
$value556 = ($arguments554['value'] !== NULL ? $arguments554['value'] : $renderChildrenClosure555());

$output553 .= (!is_string($value556) ? $value556 : htmlspecialchars($value556, ($arguments554['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments554['encoding'] !== NULL ? $arguments554['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments554['doubleEncode']));

$output553 .= ']
											';
return $output553;
};
$viewHelper557 = $self->getViewHelper('$viewHelper557', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper557->setArguments($arguments551);
$viewHelper557->setRenderingContext($renderingContext);
$viewHelper557->setRenderChildrenClosure($renderChildrenClosure552);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output542 .= $viewHelper557->initializeArgumentsAndRender();

$output542 .= '
										';
return $output542;
};
$arguments536['__thenClosure'] = function() use ($renderingContext, $self) {
$output558 = '';

$output558 .= '
												';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments559 = array();
$output560 = '';

$output560 .= 'type_';

$output560 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments559['key'] = $output560;
$arguments559['id'] = NULL;
$arguments559['default'] = NULL;
$arguments559['htmlEscape'] = NULL;
$arguments559['arguments'] = NULL;
$arguments559['extensionName'] = NULL;
$renderChildrenClosure561 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper562 = $self->getViewHelper('$viewHelper562', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper562->setArguments($arguments559);
$viewHelper562->setRenderingContext($renderingContext);
$viewHelper562->setRenderChildrenClosure($renderChildrenClosure561);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output558 .= $viewHelper562->initializeArgumentsAndRender();

$output558 .= '
											';
return $output558;
};
$arguments536['__elseClosure'] = function() use ($renderingContext, $self) {
$output563 = '';

$output563 .= '
												[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments564 = array();
$arguments564['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments564['keepQuotes'] = false;
$arguments564['encoding'] = NULL;
$arguments564['doubleEncode'] = true;
$renderChildrenClosure565 = function() use ($renderingContext, $self) {
return NULL;
};
$value566 = ($arguments564['value'] !== NULL ? $arguments564['value'] : $renderChildrenClosure565());

$output563 .= (!is_string($value566) ? $value566 : htmlspecialchars($value566, ($arguments564['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments564['encoding'] !== NULL ? $arguments564['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments564['doubleEncode']));

$output563 .= ']
											';
return $output563;
};
$viewHelper567 = $self->getViewHelper('$viewHelper567', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper567->setArguments($arguments536);
$viewHelper567->setRenderingContext($renderingContext);
$viewHelper567->setRenderChildrenClosure($renderChildrenClosure541);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output535 .= $viewHelper567->initializeArgumentsAndRender();

$output535 .= '
									';
return $output535;
};
$viewHelper568 = $self->getViewHelper('$viewHelper568', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper568->setArguments($arguments485);
$viewHelper568->setRenderingContext($renderingContext);
$viewHelper568->setRenderChildrenClosure($renderChildrenClosure486);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output423 .= $viewHelper568->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>

							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments569 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments570 = array();
$output571 = '';

$output571 .= 'action_';

$output571 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);

$output571 .= '_';

$output571 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments570['key'] = $output571;
$arguments570['id'] = NULL;
$arguments570['default'] = NULL;
$arguments570['htmlEscape'] = NULL;
$arguments570['arguments'] = NULL;
$arguments570['extensionName'] = NULL;
$renderChildrenClosure572 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper573 = $self->getViewHelper('$viewHelper573', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper573->setArguments($arguments570);
$viewHelper573->setRenderingContext($renderingContext);
$viewHelper573->setRenderChildrenClosure($renderChildrenClosure572);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments569['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper573->initializeArgumentsAndRender());
$arguments569['then'] = NULL;
$arguments569['else'] = NULL;
$renderChildrenClosure574 = function() use ($renderingContext, $self) {
$output575 = '';

$output575 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments576 = array();
$renderChildrenClosure577 = function() use ($renderingContext, $self) {
$output578 = '';

$output578 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments579 = array();
$output580 = '';

$output580 .= 'action_';

$output580 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);

$output580 .= '_';

$output580 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments579['key'] = $output580;
// Rendering Boolean node
$arguments579['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
$arguments579['id'] = NULL;
$arguments579['default'] = NULL;
$arguments579['arguments'] = NULL;
$arguments579['extensionName'] = NULL;
$renderChildrenClosure581 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper582 = $self->getViewHelper('$viewHelper582', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper582->setArguments($arguments579);
$viewHelper582->setRenderingContext($renderingContext);
$viewHelper582->setRenderChildrenClosure($renderChildrenClosure581);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output578 .= $viewHelper582->initializeArgumentsAndRender();

$output578 .= '
									';
return $output578;
};
$viewHelper583 = $self->getViewHelper('$viewHelper583', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper583->setArguments($arguments576);
$viewHelper583->setRenderingContext($renderingContext);
$viewHelper583->setRenderChildrenClosure($renderChildrenClosure577);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output575 .= $viewHelper583->initializeArgumentsAndRender();

$output575 .= '
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments584 = array();
$renderChildrenClosure585 = function() use ($renderingContext, $self) {
$output586 = '';

$output586 .= '
										[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments587 = array();
$arguments587['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments587['keepQuotes'] = false;
$arguments587['encoding'] = NULL;
$arguments587['doubleEncode'] = true;
$renderChildrenClosure588 = function() use ($renderingContext, $self) {
return NULL;
};
$value589 = ($arguments587['value'] !== NULL ? $arguments587['value'] : $renderChildrenClosure588());

$output586 .= (!is_string($value589) ? $value589 : htmlspecialchars($value589, ($arguments587['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments587['encoding'] !== NULL ? $arguments587['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments587['doubleEncode']));

$output586 .= ']
									';
return $output586;
};
$viewHelper590 = $self->getViewHelper('$viewHelper590', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper590->setArguments($arguments584);
$viewHelper590->setRenderingContext($renderingContext);
$viewHelper590->setRenderChildrenClosure($renderChildrenClosure585);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output575 .= $viewHelper590->initializeArgumentsAndRender();

$output575 .= '
								';
return $output575;
};
$arguments569['__thenClosure'] = function() use ($renderingContext, $self) {
$output591 = '';

$output591 .= '
										';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments592 = array();
$output593 = '';

$output593 .= 'action_';

$output593 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);

$output593 .= '_';

$output593 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments592['key'] = $output593;
// Rendering Boolean node
$arguments592['htmlEscape'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean('0');
$arguments592['id'] = NULL;
$arguments592['default'] = NULL;
$arguments592['arguments'] = NULL;
$arguments592['extensionName'] = NULL;
$renderChildrenClosure594 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper595 = $self->getViewHelper('$viewHelper595', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper595->setArguments($arguments592);
$viewHelper595->setRenderingContext($renderingContext);
$viewHelper595->setRenderChildrenClosure($renderChildrenClosure594);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output591 .= $viewHelper595->initializeArgumentsAndRender();

$output591 .= '
									';
return $output591;
};
$arguments569['__elseClosure'] = function() use ($renderingContext, $self) {
$output596 = '';

$output596 .= '
										[';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments597 = array();
$arguments597['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments597['keepQuotes'] = false;
$arguments597['encoding'] = NULL;
$arguments597['doubleEncode'] = true;
$renderChildrenClosure598 = function() use ($renderingContext, $self) {
return NULL;
};
$value599 = ($arguments597['value'] !== NULL ? $arguments597['value'] : $renderChildrenClosure598());

$output596 .= (!is_string($value599) ? $value599 : htmlspecialchars($value599, ($arguments597['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments597['encoding'] !== NULL ? $arguments597['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments597['doubleEncode']));

$output596 .= ']
									';
return $output596;
};
$viewHelper600 = $self->getViewHelper('$viewHelper600', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper600->setArguments($arguments569);
$viewHelper600->setRenderingContext($renderingContext);
$viewHelper600->setRenderChildrenClosure($renderChildrenClosure574);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output423 .= $viewHelper600->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>

							<td valign="top">
								';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\FormatDetailsViewHelper
$arguments601 = array();
$arguments601['logEntry'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem', $renderingContext);
$renderChildrenClosure602 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper603 = $self->getViewHelper('$viewHelper603', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\FormatDetailsViewHelper');
$viewHelper603->setArguments($arguments601);
$viewHelper603->setRenderingContext($renderingContext);
$viewHelper603->setRenderChildrenClosure($renderChildrenClosure602);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\FormatDetailsViewHelper

$output423 .= $viewHelper603->initializeArgumentsAndRender();

$output423 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\HistoryEntryViewHelper
$arguments604 = array();
$arguments604['uid'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.uid', $renderingContext);
$renderChildrenClosure605 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper606 = $self->getViewHelper('$viewHelper606', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\HistoryEntryViewHelper');
$viewHelper606->setArguments($arguments604);
$viewHelper606->setRenderingContext($renderingContext);
$viewHelper606->setRenderChildrenClosure($renderChildrenClosure605);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\HistoryEntryViewHelper

$output423 .= $viewHelper606->initializeArgumentsAndRender();

$output423 .= '
								';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments607 = array();
// Rendering Boolean node
$arguments607['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('>', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.detailsNumber', $renderingContext), 0);
$arguments607['then'] = NULL;
$arguments607['else'] = NULL;
$renderChildrenClosure608 = function() use ($renderingContext, $self) {
$output609 = '';

$output609 .= '
									(msg#';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments610 = array();
$arguments610['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.type', $renderingContext);
$arguments610['keepQuotes'] = false;
$arguments610['encoding'] = NULL;
$arguments610['doubleEncode'] = true;
$renderChildrenClosure611 = function() use ($renderingContext, $self) {
return NULL;
};
$value612 = ($arguments610['value'] !== NULL ? $arguments610['value'] : $renderChildrenClosure611());

$output609 .= (!is_string($value612) ? $value612 : htmlspecialchars($value612, ($arguments610['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments610['encoding'] !== NULL ? $arguments610['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments610['doubleEncode']));

$output609 .= '.';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments613 = array();
$arguments613['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.action', $renderingContext);
$arguments613['keepQuotes'] = false;
$arguments613['encoding'] = NULL;
$arguments613['doubleEncode'] = true;
$renderChildrenClosure614 = function() use ($renderingContext, $self) {
return NULL;
};
$value615 = ($arguments613['value'] !== NULL ? $arguments613['value'] : $renderChildrenClosure614());

$output609 .= (!is_string($value615) ? $value615 : htmlspecialchars($value615, ($arguments613['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments613['encoding'] !== NULL ? $arguments613['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments613['doubleEncode']));

$output609 .= '.';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments616 = array();
$arguments616['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'logItem.detailsNumber', $renderingContext);
$arguments616['keepQuotes'] = false;
$arguments616['encoding'] = NULL;
$arguments616['doubleEncode'] = true;
$renderChildrenClosure617 = function() use ($renderingContext, $self) {
return NULL;
};
$value618 = ($arguments616['value'] !== NULL ? $arguments616['value'] : $renderChildrenClosure617());

$output609 .= (!is_string($value618) ? $value618 : htmlspecialchars($value618, ($arguments616['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments616['encoding'] !== NULL ? $arguments616['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments616['doubleEncode']));

$output609 .= ')
								';
return $output609;
};
$viewHelper619 = $self->getViewHelper('$viewHelper619', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper619->setArguments($arguments607);
$viewHelper619->setRenderingContext($renderingContext);
$viewHelper619->setRenderChildrenClosure($renderChildrenClosure608);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output423 .= $viewHelper619->initializeArgumentsAndRender();

$output423 .= '
							</td>
							<td><img src="clear.gif" width="10" height="1" alt="" /></td>
						</tr>
					';
return $output423;
};

$output375 .= TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper::renderStatic($arguments421, $renderChildrenClosure422, $renderingContext);

$output375 .= '
				</tbody>
			</table>
		';
return $output375;
};

$output38 .= TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper::renderStatic($arguments373, $renderChildrenClosure374, $renderingContext);

$output38 .= '
	</div>
';
return $output38;
};

$output0 .= TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper::renderStatic($arguments36, $renderChildrenClosure37, $renderingContext);

return $output0;
}


}
#1413340042    152092    