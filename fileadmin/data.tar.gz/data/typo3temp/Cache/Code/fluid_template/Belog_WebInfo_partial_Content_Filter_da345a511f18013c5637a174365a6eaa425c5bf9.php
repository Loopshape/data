<?php
class FluidCache_Belog_WebInfo_partial_Content_Filter_da345a511f18013c5637a174365a6eaa425c5bf9 extends \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate {

public function getVariableContainer() {
	// TODO
	return new \TYPO3\CMS\Fluid\Core\ViewHelper\TemplateVariableContainer();
}
public function getLayoutName(\TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {

return NULL;
}
public function hasLayout() {
return FALSE;
}

/**
 * Main Render function
 */
public function render(\TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$self = $this;
$output0 = '';

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper
$arguments1 = array();
$arguments1['file'] = 'sysext/backend/Resources/Public/JavaScript/tceforms.js';
$renderChildrenClosure2 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper3 = $self->getViewHelper('$viewHelper3', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper');
$viewHelper3->setArguments($arguments1);
$viewHelper3->setRenderingContext($renderingContext);
$viewHelper3->setRenderChildrenClosure($renderChildrenClosure2);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper

$output0 .= $viewHelper3->initializeArgumentsAndRender();

$output0 .= '
';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper
$arguments4 = array();
$arguments4['file'] = 'js/extjs/ux/Ext.ux.DateTimePicker.js';
$renderChildrenClosure5 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper6 = $self->getViewHelper('$viewHelper6', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper');
$viewHelper6->setArguments($arguments4);
$viewHelper6->setRenderingContext($renderingContext);
$viewHelper6->setRenderChildrenClosure($renderChildrenClosure5);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\AddJsFileViewHelper

$output0 .= $viewHelper6->initializeArgumentsAndRender();

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\InlineSettingsArrayViewHelper
$arguments7 = array();
// Rendering Array
$array8 = array();
$array8['datePickerUSmode'] = 0;
// Rendering Array
$array9 = array();
$array9['0'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);
$output10 = '';

$output10 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output10 .= ' ';

$output10 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.timeFormat', $renderingContext);
$array9['1'] = $output10;
$array8['dateFormat'] = $array9;
$arguments7['settings'] = $array8;
$renderChildrenClosure11 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper12 = $self->getViewHelper('$viewHelper12', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Be\InlineSettingsArrayViewHelper');
$viewHelper12->setArguments($arguments7);
$viewHelper12->setRenderingContext($renderingContext);
$viewHelper12->setRenderChildrenClosure($renderChildrenClosure11);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Be\InlineSettingsArrayViewHelper

$output0 .= $viewHelper12->initializeArgumentsAndRender();

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments13 = array();
$renderChildrenClosure14 = function() use ($renderingContext, $self) {
return '
	This is an ugly workaround.
	The function module in Web->Info already renders a form tag, and there is
	no easy way to circumvent this. The page id is needed for the info module
	that is not extbase based to figure the permissions. Thus, we have to add
	the page Id manually to hint the info module about that.
';
};
$viewHelper15 = $self->getViewHelper('$viewHelper15', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper15->setArguments($arguments13);
$viewHelper15->setRenderingContext($renderingContext);
$viewHelper15->setRenderChildrenClosure($renderChildrenClosure14);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output0 .= $viewHelper15->initializeArgumentsAndRender();

$output0 .= '
';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments16 = array();
// Rendering Boolean node
$arguments16['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.isInPageContext', $renderingContext));
$arguments16['then'] = NULL;
$arguments16['else'] = NULL;
$renderChildrenClosure17 = function() use ($renderingContext, $self) {
$output18 = '';

$output18 .= '
	<input type="hidden" name="id" value="';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper
$arguments19 = array();
$arguments19['value'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.pageId', $renderingContext);
$arguments19['keepQuotes'] = false;
$arguments19['encoding'] = NULL;
$arguments19['doubleEncode'] = true;
$renderChildrenClosure20 = function() use ($renderingContext, $self) {
return NULL;
};
$value21 = ($arguments19['value'] !== NULL ? $arguments19['value'] : $renderChildrenClosure20());

$output18 .= (!is_string($value21) ? $value21 : htmlspecialchars($value21, ($arguments19['keepQuotes'] ? ENT_NOQUOTES : ENT_COMPAT), ($arguments19['encoding'] !== NULL ? $arguments19['encoding'] : \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate::resolveDefaultEncoding()), $arguments19['doubleEncode']));

$output18 .= '" />
';
return $output18;
};
$viewHelper22 = $self->getViewHelper('$viewHelper22', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper22->setArguments($arguments16);
$viewHelper22->setRenderingContext($renderingContext);
$viewHelper22->setRenderChildrenClosure($renderChildrenClosure17);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output0 .= $viewHelper22->initializeArgumentsAndRender();

$output0 .= '

';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper
$arguments23 = array();
$arguments23['object'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint', $renderingContext);
$arguments23['action'] = 'index';
$arguments23['name'] = 'constraint';
$arguments23['additionalAttributes'] = NULL;
$arguments23['arguments'] = array (
);
$arguments23['controller'] = NULL;
$arguments23['extensionName'] = NULL;
$arguments23['pluginName'] = NULL;
$arguments23['pageUid'] = NULL;
$arguments23['pageType'] = 0;
$arguments23['noCache'] = false;
$arguments23['noCacheHash'] = false;
$arguments23['section'] = '';
$arguments23['format'] = '';
$arguments23['additionalParams'] = array (
);
$arguments23['absolute'] = false;
$arguments23['addQueryString'] = false;
$arguments23['argumentsToBeExcludedFromQueryString'] = array (
);
$arguments23['fieldNamePrefix'] = NULL;
$arguments23['actionUri'] = NULL;
$arguments23['objectName'] = NULL;
$arguments23['hiddenFieldClassName'] = NULL;
$arguments23['enctype'] = NULL;
$arguments23['method'] = NULL;
$arguments23['onreset'] = NULL;
$arguments23['onsubmit'] = NULL;
$arguments23['class'] = NULL;
$arguments23['dir'] = NULL;
$arguments23['id'] = NULL;
$arguments23['lang'] = NULL;
$arguments23['style'] = NULL;
$arguments23['title'] = NULL;
$arguments23['accesskey'] = NULL;
$arguments23['tabindex'] = NULL;
$arguments23['onclick'] = NULL;
$renderChildrenClosure24 = function() use ($renderingContext, $self) {
$output25 = '';

$output25 .= '
	<table border="0" cellpadding="0" cellspacing="0">
		<tbody>
			<tr>
				<th>
					<label for="belog-users">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments26 = array();
$arguments26['key'] = 'users';
$arguments26['id'] = NULL;
$arguments26['default'] = NULL;
$arguments26['htmlEscape'] = NULL;
$arguments26['arguments'] = NULL;
$arguments26['extensionName'] = NULL;
$renderChildrenClosure27 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper28 = $self->getViewHelper('$viewHelper28', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper28->setArguments($arguments26);
$viewHelper28->setRenderingContext($renderingContext);
$viewHelper28->setRenderChildrenClosure($renderChildrenClosure27);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output25 .= $viewHelper28->initializeArgumentsAndRender();

$output25 .= '</label>
				</th>
				<td>
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments29 = array();
$arguments29['property'] = 'userOrGroup';
$arguments29['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'userGroups', $renderingContext);
// Rendering Array
$array30 = array();
$array30['onchange'] = 'submit()';
$arguments29['additionalAttributes'] = $array30;
$arguments29['id'] = 'belog-users';
$arguments29['name'] = NULL;
$arguments29['value'] = NULL;
$arguments29['class'] = NULL;
$arguments29['dir'] = NULL;
$arguments29['lang'] = NULL;
$arguments29['style'] = NULL;
$arguments29['title'] = NULL;
$arguments29['accesskey'] = NULL;
$arguments29['tabindex'] = NULL;
$arguments29['onclick'] = NULL;
$arguments29['multiple'] = NULL;
$arguments29['size'] = NULL;
$arguments29['disabled'] = NULL;
$arguments29['optionValueField'] = NULL;
$arguments29['optionLabelField'] = NULL;
$arguments29['sortByOptionLabel'] = false;
$arguments29['selectAllByDefault'] = false;
$arguments29['errorClass'] = 'f3-form-error';
$arguments29['prependOptionLabel'] = NULL;
$arguments29['prependOptionValue'] = NULL;
$renderChildrenClosure31 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper32 = $self->getViewHelper('$viewHelper32', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper32->setArguments($arguments29);
$viewHelper32->setRenderingContext($renderingContext);
$viewHelper32->setRenderChildrenClosure($renderChildrenClosure31);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output25 .= $viewHelper32->initializeArgumentsAndRender();

$output25 .= '
				</td>

				<th>
					<label for="belog-max">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments33 = array();
$arguments33['key'] = 'max';
$arguments33['id'] = NULL;
$arguments33['default'] = NULL;
$arguments33['htmlEscape'] = NULL;
$arguments33['arguments'] = NULL;
$arguments33['extensionName'] = NULL;
$renderChildrenClosure34 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper35 = $self->getViewHelper('$viewHelper35', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper35->setArguments($arguments33);
$viewHelper35->setRenderingContext($renderingContext);
$viewHelper35->setRenderChildrenClosure($renderChildrenClosure34);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output25 .= $viewHelper35->initializeArgumentsAndRender();

$output25 .= '</label>
				</th>
				<td>
					';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper
$arguments36 = array();
$arguments36['property'] = 'number';
$arguments36['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.selectableNumberOfLogEntries', $renderingContext);
$arguments36['optionLabelPrefix'] = 'LLL:EXT:belog/Resources/Private/Language/locallang.xlf:';
// Rendering Array
$array37 = array();
$array37['onchange'] = 'submit()';
$arguments36['additionalAttributes'] = $array37;
$arguments36['id'] = 'belog-max';
$arguments36['name'] = NULL;
$arguments36['value'] = NULL;
$arguments36['class'] = NULL;
$arguments36['dir'] = NULL;
$arguments36['lang'] = NULL;
$arguments36['style'] = NULL;
$arguments36['title'] = NULL;
$arguments36['accesskey'] = NULL;
$arguments36['tabindex'] = NULL;
$arguments36['onclick'] = NULL;
$arguments36['multiple'] = NULL;
$arguments36['size'] = NULL;
$arguments36['disabled'] = NULL;
$arguments36['optionValueField'] = NULL;
$arguments36['optionLabelField'] = NULL;
$arguments36['sortByOptionLabel'] = false;
$arguments36['selectAllByDefault'] = false;
$arguments36['errorClass'] = 'f3-form-error';
$arguments36['prependOptionLabel'] = NULL;
$arguments36['prependOptionValue'] = NULL;
$renderChildrenClosure38 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper39 = $self->getViewHelper('$viewHelper39', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper');
$viewHelper39->setArguments($arguments36);
$viewHelper39->setRenderingContext($renderingContext);
$viewHelper39->setRenderChildrenClosure($renderChildrenClosure38);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper

$output25 .= $viewHelper39->initializeArgumentsAndRender();

$output25 .= '
				</td>

				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments40 = array();
// Rendering Boolean node
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\IsExtensionLoadedViewHelper
$arguments41 = array();
$arguments41['extensionKey'] = 'workspaces';
$renderChildrenClosure42 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper43 = $self->getViewHelper('$viewHelper43', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\IsExtensionLoadedViewHelper');
$viewHelper43->setArguments($arguments41);
$viewHelper43->setRenderingContext($renderingContext);
$viewHelper43->setRenderChildrenClosure($renderChildrenClosure42);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\IsExtensionLoadedViewHelper
$arguments40['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean($viewHelper43->initializeArgumentsAndRender());
$arguments40['then'] = NULL;
$arguments40['else'] = NULL;
$renderChildrenClosure44 = function() use ($renderingContext, $self) {
$output45 = '';

$output45 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments46 = array();
$renderChildrenClosure47 = function() use ($renderingContext, $self) {
$output48 = '';

$output48 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments49 = array();
// Rendering Boolean node
$arguments49['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'showWorkspaceSelector', $renderingContext));
$arguments49['then'] = NULL;
$arguments49['else'] = NULL;
$renderChildrenClosure50 = function() use ($renderingContext, $self) {
$output51 = '';

$output51 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments52 = array();
$renderChildrenClosure53 = function() use ($renderingContext, $self) {
$output54 = '';

$output54 .= '
								<th>
									<label for="belog-workspaces">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments55 = array();
$arguments55['key'] = 'workspace';
$arguments55['id'] = NULL;
$arguments55['default'] = NULL;
$arguments55['htmlEscape'] = NULL;
$arguments55['arguments'] = NULL;
$arguments55['extensionName'] = NULL;
$renderChildrenClosure56 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper57 = $self->getViewHelper('$viewHelper57', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper57->setArguments($arguments55);
$viewHelper57->setRenderingContext($renderingContext);
$viewHelper57->setRenderChildrenClosure($renderChildrenClosure56);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output54 .= $viewHelper57->initializeArgumentsAndRender();

$output54 .= '</label>
								</th>
								<td>
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments58 = array();
$arguments58['property'] = 'workspaceUid';
$arguments58['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'workspaces', $renderingContext);
// Rendering Array
$array59 = array();
$array59['onchange'] = 'submit()';
$arguments58['additionalAttributes'] = $array59;
$arguments58['id'] = 'belog-workspaces';
$arguments58['name'] = NULL;
$arguments58['value'] = NULL;
$arguments58['class'] = NULL;
$arguments58['dir'] = NULL;
$arguments58['lang'] = NULL;
$arguments58['style'] = NULL;
$arguments58['title'] = NULL;
$arguments58['accesskey'] = NULL;
$arguments58['tabindex'] = NULL;
$arguments58['onclick'] = NULL;
$arguments58['multiple'] = NULL;
$arguments58['size'] = NULL;
$arguments58['disabled'] = NULL;
$arguments58['optionValueField'] = NULL;
$arguments58['optionLabelField'] = NULL;
$arguments58['sortByOptionLabel'] = false;
$arguments58['selectAllByDefault'] = false;
$arguments58['errorClass'] = 'f3-form-error';
$arguments58['prependOptionLabel'] = NULL;
$arguments58['prependOptionValue'] = NULL;
$renderChildrenClosure60 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper61 = $self->getViewHelper('$viewHelper61', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper61->setArguments($arguments58);
$viewHelper61->setRenderingContext($renderingContext);
$viewHelper61->setRenderChildrenClosure($renderChildrenClosure60);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output54 .= $viewHelper61->initializeArgumentsAndRender();

$output54 .= '
								</td>
							';
return $output54;
};
$viewHelper62 = $self->getViewHelper('$viewHelper62', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper62->setArguments($arguments52);
$viewHelper62->setRenderingContext($renderingContext);
$viewHelper62->setRenderChildrenClosure($renderChildrenClosure53);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output51 .= $viewHelper62->initializeArgumentsAndRender();

$output51 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments63 = array();
$renderChildrenClosure64 = function() use ($renderingContext, $self) {
return '
								<th></th><td></td>
							';
};
$viewHelper65 = $self->getViewHelper('$viewHelper65', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper65->setArguments($arguments63);
$viewHelper65->setRenderingContext($renderingContext);
$viewHelper65->setRenderChildrenClosure($renderChildrenClosure64);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output51 .= $viewHelper65->initializeArgumentsAndRender();

$output51 .= '
						';
return $output51;
};
$arguments49['__thenClosure'] = function() use ($renderingContext, $self) {
$output66 = '';

$output66 .= '
								<th>
									<label for="belog-workspaces">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments67 = array();
$arguments67['key'] = 'workspace';
$arguments67['id'] = NULL;
$arguments67['default'] = NULL;
$arguments67['htmlEscape'] = NULL;
$arguments67['arguments'] = NULL;
$arguments67['extensionName'] = NULL;
$renderChildrenClosure68 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper69 = $self->getViewHelper('$viewHelper69', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper69->setArguments($arguments67);
$viewHelper69->setRenderingContext($renderingContext);
$viewHelper69->setRenderChildrenClosure($renderChildrenClosure68);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output66 .= $viewHelper69->initializeArgumentsAndRender();

$output66 .= '</label>
								</th>
								<td>
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments70 = array();
$arguments70['property'] = 'workspaceUid';
$arguments70['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'workspaces', $renderingContext);
// Rendering Array
$array71 = array();
$array71['onchange'] = 'submit()';
$arguments70['additionalAttributes'] = $array71;
$arguments70['id'] = 'belog-workspaces';
$arguments70['name'] = NULL;
$arguments70['value'] = NULL;
$arguments70['class'] = NULL;
$arguments70['dir'] = NULL;
$arguments70['lang'] = NULL;
$arguments70['style'] = NULL;
$arguments70['title'] = NULL;
$arguments70['accesskey'] = NULL;
$arguments70['tabindex'] = NULL;
$arguments70['onclick'] = NULL;
$arguments70['multiple'] = NULL;
$arguments70['size'] = NULL;
$arguments70['disabled'] = NULL;
$arguments70['optionValueField'] = NULL;
$arguments70['optionLabelField'] = NULL;
$arguments70['sortByOptionLabel'] = false;
$arguments70['selectAllByDefault'] = false;
$arguments70['errorClass'] = 'f3-form-error';
$arguments70['prependOptionLabel'] = NULL;
$arguments70['prependOptionValue'] = NULL;
$renderChildrenClosure72 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper73 = $self->getViewHelper('$viewHelper73', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper73->setArguments($arguments70);
$viewHelper73->setRenderingContext($renderingContext);
$viewHelper73->setRenderChildrenClosure($renderChildrenClosure72);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output66 .= $viewHelper73->initializeArgumentsAndRender();

$output66 .= '
								</td>
							';
return $output66;
};
$arguments49['__elseClosure'] = function() use ($renderingContext, $self) {
return '
								<th></th><td></td>
							';
};
$viewHelper74 = $self->getViewHelper('$viewHelper74', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper74->setArguments($arguments49);
$viewHelper74->setRenderingContext($renderingContext);
$viewHelper74->setRenderChildrenClosure($renderChildrenClosure50);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output48 .= $viewHelper74->initializeArgumentsAndRender();

$output48 .= '
					';
return $output48;
};
$viewHelper75 = $self->getViewHelper('$viewHelper75', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper75->setArguments($arguments46);
$viewHelper75->setRenderingContext($renderingContext);
$viewHelper75->setRenderChildrenClosure($renderChildrenClosure47);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output45 .= $viewHelper75->initializeArgumentsAndRender();

$output45 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments76 = array();
$renderChildrenClosure77 = function() use ($renderingContext, $self) {
return '
						<th></th><td></td>
					';
};
$viewHelper78 = $self->getViewHelper('$viewHelper78', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper78->setArguments($arguments76);
$viewHelper78->setRenderingContext($renderingContext);
$viewHelper78->setRenderChildrenClosure($renderChildrenClosure77);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output45 .= $viewHelper78->initializeArgumentsAndRender();

$output45 .= '
				';
return $output45;
};
$arguments40['__thenClosure'] = function() use ($renderingContext, $self) {
$output79 = '';

$output79 .= '
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments80 = array();
// Rendering Boolean node
$arguments80['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'showWorkspaceSelector', $renderingContext));
$arguments80['then'] = NULL;
$arguments80['else'] = NULL;
$renderChildrenClosure81 = function() use ($renderingContext, $self) {
$output82 = '';

$output82 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments83 = array();
$renderChildrenClosure84 = function() use ($renderingContext, $self) {
$output85 = '';

$output85 .= '
								<th>
									<label for="belog-workspaces">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments86 = array();
$arguments86['key'] = 'workspace';
$arguments86['id'] = NULL;
$arguments86['default'] = NULL;
$arguments86['htmlEscape'] = NULL;
$arguments86['arguments'] = NULL;
$arguments86['extensionName'] = NULL;
$renderChildrenClosure87 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper88 = $self->getViewHelper('$viewHelper88', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper88->setArguments($arguments86);
$viewHelper88->setRenderingContext($renderingContext);
$viewHelper88->setRenderChildrenClosure($renderChildrenClosure87);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output85 .= $viewHelper88->initializeArgumentsAndRender();

$output85 .= '</label>
								</th>
								<td>
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments89 = array();
$arguments89['property'] = 'workspaceUid';
$arguments89['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'workspaces', $renderingContext);
// Rendering Array
$array90 = array();
$array90['onchange'] = 'submit()';
$arguments89['additionalAttributes'] = $array90;
$arguments89['id'] = 'belog-workspaces';
$arguments89['name'] = NULL;
$arguments89['value'] = NULL;
$arguments89['class'] = NULL;
$arguments89['dir'] = NULL;
$arguments89['lang'] = NULL;
$arguments89['style'] = NULL;
$arguments89['title'] = NULL;
$arguments89['accesskey'] = NULL;
$arguments89['tabindex'] = NULL;
$arguments89['onclick'] = NULL;
$arguments89['multiple'] = NULL;
$arguments89['size'] = NULL;
$arguments89['disabled'] = NULL;
$arguments89['optionValueField'] = NULL;
$arguments89['optionLabelField'] = NULL;
$arguments89['sortByOptionLabel'] = false;
$arguments89['selectAllByDefault'] = false;
$arguments89['errorClass'] = 'f3-form-error';
$arguments89['prependOptionLabel'] = NULL;
$arguments89['prependOptionValue'] = NULL;
$renderChildrenClosure91 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper92 = $self->getViewHelper('$viewHelper92', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper92->setArguments($arguments89);
$viewHelper92->setRenderingContext($renderingContext);
$viewHelper92->setRenderChildrenClosure($renderChildrenClosure91);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output85 .= $viewHelper92->initializeArgumentsAndRender();

$output85 .= '
								</td>
							';
return $output85;
};
$viewHelper93 = $self->getViewHelper('$viewHelper93', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper93->setArguments($arguments83);
$viewHelper93->setRenderingContext($renderingContext);
$viewHelper93->setRenderChildrenClosure($renderChildrenClosure84);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output82 .= $viewHelper93->initializeArgumentsAndRender();

$output82 .= '
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments94 = array();
$renderChildrenClosure95 = function() use ($renderingContext, $self) {
return '
								<th></th><td></td>
							';
};
$viewHelper96 = $self->getViewHelper('$viewHelper96', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper96->setArguments($arguments94);
$viewHelper96->setRenderingContext($renderingContext);
$viewHelper96->setRenderChildrenClosure($renderChildrenClosure95);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output82 .= $viewHelper96->initializeArgumentsAndRender();

$output82 .= '
						';
return $output82;
};
$arguments80['__thenClosure'] = function() use ($renderingContext, $self) {
$output97 = '';

$output97 .= '
								<th>
									<label for="belog-workspaces">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments98 = array();
$arguments98['key'] = 'workspace';
$arguments98['id'] = NULL;
$arguments98['default'] = NULL;
$arguments98['htmlEscape'] = NULL;
$arguments98['arguments'] = NULL;
$arguments98['extensionName'] = NULL;
$renderChildrenClosure99 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper100 = $self->getViewHelper('$viewHelper100', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper100->setArguments($arguments98);
$viewHelper100->setRenderingContext($renderingContext);
$viewHelper100->setRenderChildrenClosure($renderChildrenClosure99);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output97 .= $viewHelper100->initializeArgumentsAndRender();

$output97 .= '</label>
								</th>
								<td>
									';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments101 = array();
$arguments101['property'] = 'workspaceUid';
$arguments101['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'workspaces', $renderingContext);
// Rendering Array
$array102 = array();
$array102['onchange'] = 'submit()';
$arguments101['additionalAttributes'] = $array102;
$arguments101['id'] = 'belog-workspaces';
$arguments101['name'] = NULL;
$arguments101['value'] = NULL;
$arguments101['class'] = NULL;
$arguments101['dir'] = NULL;
$arguments101['lang'] = NULL;
$arguments101['style'] = NULL;
$arguments101['title'] = NULL;
$arguments101['accesskey'] = NULL;
$arguments101['tabindex'] = NULL;
$arguments101['onclick'] = NULL;
$arguments101['multiple'] = NULL;
$arguments101['size'] = NULL;
$arguments101['disabled'] = NULL;
$arguments101['optionValueField'] = NULL;
$arguments101['optionLabelField'] = NULL;
$arguments101['sortByOptionLabel'] = false;
$arguments101['selectAllByDefault'] = false;
$arguments101['errorClass'] = 'f3-form-error';
$arguments101['prependOptionLabel'] = NULL;
$arguments101['prependOptionValue'] = NULL;
$renderChildrenClosure103 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper104 = $self->getViewHelper('$viewHelper104', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper104->setArguments($arguments101);
$viewHelper104->setRenderingContext($renderingContext);
$viewHelper104->setRenderChildrenClosure($renderChildrenClosure103);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output97 .= $viewHelper104->initializeArgumentsAndRender();

$output97 .= '
								</td>
							';
return $output97;
};
$arguments80['__elseClosure'] = function() use ($renderingContext, $self) {
return '
								<th></th><td></td>
							';
};
$viewHelper105 = $self->getViewHelper('$viewHelper105', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper105->setArguments($arguments80);
$viewHelper105->setRenderingContext($renderingContext);
$viewHelper105->setRenderChildrenClosure($renderChildrenClosure81);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output79 .= $viewHelper105->initializeArgumentsAndRender();

$output79 .= '
					';
return $output79;
};
$arguments40['__elseClosure'] = function() use ($renderingContext, $self) {
return '
						<th></th><td></td>
					';
};
$viewHelper106 = $self->getViewHelper('$viewHelper106', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper106->setArguments($arguments40);
$viewHelper106->setRenderingContext($renderingContext);
$viewHelper106->setRenderChildrenClosure($renderChildrenClosure44);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output25 .= $viewHelper106->initializeArgumentsAndRender();

$output25 .= '

				';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments107 = array();
// Rendering Boolean node
$arguments107['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::convertToBoolean(TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.isInPageContext', $renderingContext));
$arguments107['then'] = NULL;
$arguments107['else'] = NULL;
$renderChildrenClosure108 = function() use ($renderingContext, $self) {
$output109 = '';

$output109 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper
$arguments110 = array();
$renderChildrenClosure111 = function() use ($renderingContext, $self) {
$output112 = '';

$output112 .= '
						<th>
							<label for="belog-depth">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments113 = array();
$arguments113['key'] = 'chLog_menuDepth';
$arguments113['id'] = NULL;
$arguments113['default'] = NULL;
$arguments113['htmlEscape'] = NULL;
$arguments113['arguments'] = NULL;
$arguments113['extensionName'] = NULL;
$renderChildrenClosure114 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper115 = $self->getViewHelper('$viewHelper115', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper115->setArguments($arguments113);
$viewHelper115->setRenderingContext($renderingContext);
$viewHelper115->setRenderChildrenClosure($renderChildrenClosure114);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output112 .= $viewHelper115->initializeArgumentsAndRender();

$output112 .= '</label>
						</th>
						<td>
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments116 = array();
$arguments116['property'] = 'depth';
$arguments116['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pageDepths', $renderingContext);
// Rendering Array
$array117 = array();
$array117['onchange'] = 'submit()';
$arguments116['additionalAttributes'] = $array117;
$arguments116['id'] = 'belog-depth';
$arguments116['name'] = NULL;
$arguments116['value'] = NULL;
$arguments116['class'] = NULL;
$arguments116['dir'] = NULL;
$arguments116['lang'] = NULL;
$arguments116['style'] = NULL;
$arguments116['title'] = NULL;
$arguments116['accesskey'] = NULL;
$arguments116['tabindex'] = NULL;
$arguments116['onclick'] = NULL;
$arguments116['multiple'] = NULL;
$arguments116['size'] = NULL;
$arguments116['disabled'] = NULL;
$arguments116['optionValueField'] = NULL;
$arguments116['optionLabelField'] = NULL;
$arguments116['sortByOptionLabel'] = false;
$arguments116['selectAllByDefault'] = false;
$arguments116['errorClass'] = 'f3-form-error';
$arguments116['prependOptionLabel'] = NULL;
$arguments116['prependOptionValue'] = NULL;
$renderChildrenClosure118 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper119 = $self->getViewHelper('$viewHelper119', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper119->setArguments($arguments116);
$viewHelper119->setRenderingContext($renderingContext);
$viewHelper119->setRenderChildrenClosure($renderChildrenClosure118);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output112 .= $viewHelper119->initializeArgumentsAndRender();

$output112 .= '
						</td>
					';
return $output112;
};
$viewHelper120 = $self->getViewHelper('$viewHelper120', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper');
$viewHelper120->setArguments($arguments110);
$viewHelper120->setRenderingContext($renderingContext);
$viewHelper120->setRenderChildrenClosure($renderChildrenClosure111);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper

$output109 .= $viewHelper120->initializeArgumentsAndRender();

$output109 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper
$arguments121 = array();
$renderChildrenClosure122 = function() use ($renderingContext, $self) {
return '
						<th></th><td></td>
					';
};
$viewHelper123 = $self->getViewHelper('$viewHelper123', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper');
$viewHelper123->setArguments($arguments121);
$viewHelper123->setRenderingContext($renderingContext);
$viewHelper123->setRenderChildrenClosure($renderChildrenClosure122);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper

$output109 .= $viewHelper123->initializeArgumentsAndRender();

$output109 .= '
				';
return $output109;
};
$arguments107['__thenClosure'] = function() use ($renderingContext, $self) {
$output124 = '';

$output124 .= '
						<th>
							<label for="belog-depth">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments125 = array();
$arguments125['key'] = 'chLog_menuDepth';
$arguments125['id'] = NULL;
$arguments125['default'] = NULL;
$arguments125['htmlEscape'] = NULL;
$arguments125['arguments'] = NULL;
$arguments125['extensionName'] = NULL;
$renderChildrenClosure126 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper127 = $self->getViewHelper('$viewHelper127', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper127->setArguments($arguments125);
$viewHelper127->setRenderingContext($renderingContext);
$viewHelper127->setRenderChildrenClosure($renderChildrenClosure126);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output124 .= $viewHelper127->initializeArgumentsAndRender();

$output124 .= '</label>
						</th>
						<td>
							';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper
$arguments128 = array();
$arguments128['property'] = 'depth';
$arguments128['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'pageDepths', $renderingContext);
// Rendering Array
$array129 = array();
$array129['onchange'] = 'submit()';
$arguments128['additionalAttributes'] = $array129;
$arguments128['id'] = 'belog-depth';
$arguments128['name'] = NULL;
$arguments128['value'] = NULL;
$arguments128['class'] = NULL;
$arguments128['dir'] = NULL;
$arguments128['lang'] = NULL;
$arguments128['style'] = NULL;
$arguments128['title'] = NULL;
$arguments128['accesskey'] = NULL;
$arguments128['tabindex'] = NULL;
$arguments128['onclick'] = NULL;
$arguments128['multiple'] = NULL;
$arguments128['size'] = NULL;
$arguments128['disabled'] = NULL;
$arguments128['optionValueField'] = NULL;
$arguments128['optionLabelField'] = NULL;
$arguments128['sortByOptionLabel'] = false;
$arguments128['selectAllByDefault'] = false;
$arguments128['errorClass'] = 'f3-form-error';
$arguments128['prependOptionLabel'] = NULL;
$arguments128['prependOptionValue'] = NULL;
$renderChildrenClosure130 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper131 = $self->getViewHelper('$viewHelper131', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper');
$viewHelper131->setArguments($arguments128);
$viewHelper131->setRenderingContext($renderingContext);
$viewHelper131->setRenderChildrenClosure($renderChildrenClosure130);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper

$output124 .= $viewHelper131->initializeArgumentsAndRender();

$output124 .= '
						</td>
					';
return $output124;
};
$arguments107['__elseClosure'] = function() use ($renderingContext, $self) {
return '
						<th></th><td></td>
					';
};
$viewHelper132 = $self->getViewHelper('$viewHelper132', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper132->setArguments($arguments107);
$viewHelper132->setRenderingContext($renderingContext);
$viewHelper132->setRenderChildrenClosure($renderChildrenClosure108);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output25 .= $viewHelper132->initializeArgumentsAndRender();

$output25 .= '
			</tr>

			<tr>
				<th>
					<label for="belog-time">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments133 = array();
$arguments133['key'] = 'time';
$arguments133['id'] = NULL;
$arguments133['default'] = NULL;
$arguments133['htmlEscape'] = NULL;
$arguments133['arguments'] = NULL;
$arguments133['extensionName'] = NULL;
$renderChildrenClosure134 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper135 = $self->getViewHelper('$viewHelper135', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper135->setArguments($arguments133);
$viewHelper135->setRenderingContext($renderingContext);
$viewHelper135->setRenderChildrenClosure($renderChildrenClosure134);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output25 .= $viewHelper135->initializeArgumentsAndRender();

$output25 .= '</label>
				</th>
				<td>
					';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper
$arguments136 = array();
$arguments136['property'] = 'timeFrame';
$arguments136['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.selectableTimeFrames', $renderingContext);
$arguments136['optionLabelPrefix'] = 'LLL:EXT:belog/Resources/Private/Language/locallang.xlf:';
// Rendering Array
$array137 = array();
$array137['onchange'] = 'submit()';
$arguments136['additionalAttributes'] = $array137;
$arguments136['id'] = 'belog-time';
$arguments136['name'] = NULL;
$arguments136['value'] = NULL;
$arguments136['class'] = NULL;
$arguments136['dir'] = NULL;
$arguments136['lang'] = NULL;
$arguments136['style'] = NULL;
$arguments136['title'] = NULL;
$arguments136['accesskey'] = NULL;
$arguments136['tabindex'] = NULL;
$arguments136['onclick'] = NULL;
$arguments136['multiple'] = NULL;
$arguments136['size'] = NULL;
$arguments136['disabled'] = NULL;
$arguments136['optionValueField'] = NULL;
$arguments136['optionLabelField'] = NULL;
$arguments136['sortByOptionLabel'] = false;
$arguments136['selectAllByDefault'] = false;
$arguments136['errorClass'] = 'f3-form-error';
$arguments136['prependOptionLabel'] = NULL;
$arguments136['prependOptionValue'] = NULL;
$renderChildrenClosure138 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper139 = $self->getViewHelper('$viewHelper139', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper');
$viewHelper139->setArguments($arguments136);
$viewHelper139->setRenderingContext($renderingContext);
$viewHelper139->setRenderChildrenClosure($renderChildrenClosure138);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper

$output25 .= $viewHelper139->initializeArgumentsAndRender();

$output25 .= '

					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper
$arguments140 = array();
$renderChildrenClosure141 = function() use ($renderingContext, $self) {
return '
						Date time fields for manual date selection
					';
};
$viewHelper142 = $self->getViewHelper('$viewHelper142', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper');
$viewHelper142->setArguments($arguments140);
$viewHelper142->setRenderingContext($renderingContext);
$viewHelper142->setRenderChildrenClosure($renderChildrenClosure141);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper

$output25 .= $viewHelper142->initializeArgumentsAndRender();

$output25 .= '
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper
$arguments143 = array();
// Rendering Boolean node
$arguments143['condition'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode::evaluateComparator('==', TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.timeFrame', $renderingContext), 30);
$arguments143['then'] = NULL;
$arguments143['else'] = NULL;
$renderChildrenClosure144 = function() use ($renderingContext, $self) {
$output145 = '';

$output145 .= '
						<br />

						<label for="tceforms-datetimefield-manualDateStart">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments146 = array();
$arguments146['key'] = 'LLL:EXT:lang/locallang_common.xlf:from';
$arguments146['id'] = NULL;
$arguments146['default'] = NULL;
$arguments146['htmlEscape'] = NULL;
$arguments146['arguments'] = NULL;
$arguments146['extensionName'] = NULL;
$renderChildrenClosure147 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper148 = $self->getViewHelper('$viewHelper148', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper148->setArguments($arguments146);
$viewHelper148->setRenderingContext($renderingContext);
$viewHelper148->setRenderChildrenClosure($renderChildrenClosure147);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output145 .= $viewHelper148->initializeArgumentsAndRender();

$output145 .= '</label>&nbsp;
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper
$arguments149 = array();
$arguments149['property'] = 'manualDateStart';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments150 = array();
$output151 = '';

$output151 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output151 .= ' ';

$output151 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.timeFormat', $renderingContext);
$arguments150['format'] = $output151;
$arguments150['date'] = NULL;
$renderChildrenClosure152 = function() use ($renderingContext, $self) {
return TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.manualDateStart', $renderingContext);
};
$viewHelper153 = $self->getViewHelper('$viewHelper153', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper153->setArguments($arguments150);
$viewHelper153->setRenderingContext($renderingContext);
$viewHelper153->setRenderChildrenClosure($renderChildrenClosure152);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments149['value'] = $viewHelper153->initializeArgumentsAndRender();
$arguments149['id'] = 'tceforms-datetimefield-manualDateStart';
$arguments149['style'] = 'margin:4px 2px; padding:1px; vertical-align:middle; width: 115px;';
$arguments149['additionalAttributes'] = NULL;
$arguments149['required'] = NULL;
$arguments149['type'] = 'text';
$arguments149['name'] = NULL;
$arguments149['autofocus'] = NULL;
$arguments149['disabled'] = NULL;
$arguments149['maxlength'] = NULL;
$arguments149['readonly'] = NULL;
$arguments149['size'] = NULL;
$arguments149['placeholder'] = NULL;
$arguments149['errorClass'] = 'f3-form-error';
$arguments149['class'] = NULL;
$arguments149['dir'] = NULL;
$arguments149['lang'] = NULL;
$arguments149['title'] = NULL;
$arguments149['accesskey'] = NULL;
$arguments149['tabindex'] = NULL;
$arguments149['onclick'] = NULL;
$renderChildrenClosure154 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper155 = $self->getViewHelper('$viewHelper155', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper');
$viewHelper155->setArguments($arguments149);
$viewHelper155->setRenderingContext($renderingContext);
$viewHelper155->setRenderChildrenClosure($renderChildrenClosure154);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper

$output145 .= $viewHelper155->initializeArgumentsAndRender();

$output145 .= '
						<span
							style="cursor:pointer;"
							id="picker-tceforms-datetimefield-manualDateStart"
							class="t3-icon t3-icon-actions t3-icon-actions-edit t3-icon-edit-pick-date"
						>
							&nbsp;
						</span>

						<label for="tceforms-datetimefield-manualDateStop">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments156 = array();
$arguments156['key'] = 'LLL:EXT:lang/locallang_common.xlf:to';
$arguments156['id'] = NULL;
$arguments156['default'] = NULL;
$arguments156['htmlEscape'] = NULL;
$arguments156['arguments'] = NULL;
$arguments156['extensionName'] = NULL;
$renderChildrenClosure157 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper158 = $self->getViewHelper('$viewHelper158', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper158->setArguments($arguments156);
$viewHelper158->setRenderingContext($renderingContext);
$viewHelper158->setRenderChildrenClosure($renderChildrenClosure157);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output145 .= $viewHelper158->initializeArgumentsAndRender();

$output145 .= '</label>&nbsp;
						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper
$arguments159 = array();
$arguments159['property'] = 'manualDateStop';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments160 = array();
$output161 = '';

$output161 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.dateFormat', $renderingContext);

$output161 .= ' ';

$output161 .= TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.timeFormat', $renderingContext);
$arguments160['format'] = $output161;
$arguments160['date'] = NULL;
$renderChildrenClosure162 = function() use ($renderingContext, $self) {
return TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'constraint.manualDateStop', $renderingContext);
};
$viewHelper163 = $self->getViewHelper('$viewHelper163', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper');
$viewHelper163->setArguments($arguments160);
$viewHelper163->setRenderingContext($renderingContext);
$viewHelper163->setRenderChildrenClosure($renderChildrenClosure162);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$arguments159['value'] = $viewHelper163->initializeArgumentsAndRender();
$arguments159['id'] = 'tceforms-datetimefield-manualDateStop';
$arguments159['style'] = 'margin:4px 2px; padding:1px; vertical-align:middle; width: 115px;';
$arguments159['additionalAttributes'] = NULL;
$arguments159['required'] = NULL;
$arguments159['type'] = 'text';
$arguments159['name'] = NULL;
$arguments159['autofocus'] = NULL;
$arguments159['disabled'] = NULL;
$arguments159['maxlength'] = NULL;
$arguments159['readonly'] = NULL;
$arguments159['size'] = NULL;
$arguments159['placeholder'] = NULL;
$arguments159['errorClass'] = 'f3-form-error';
$arguments159['class'] = NULL;
$arguments159['dir'] = NULL;
$arguments159['lang'] = NULL;
$arguments159['title'] = NULL;
$arguments159['accesskey'] = NULL;
$arguments159['tabindex'] = NULL;
$arguments159['onclick'] = NULL;
$renderChildrenClosure164 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper165 = $self->getViewHelper('$viewHelper165', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper');
$viewHelper165->setArguments($arguments159);
$viewHelper165->setRenderingContext($renderingContext);
$viewHelper165->setRenderChildrenClosure($renderChildrenClosure164);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper

$output145 .= $viewHelper165->initializeArgumentsAndRender();

$output145 .= '
						<span
							style="cursor:pointer;"
							id="picker-tceforms-datetimefield-manualDateStop"
							class="t3-icon t3-icon-actions t3-icon-actions-edit t3-icon-edit-pick-date"
						>
							&nbsp;
						</span>

						';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper
$arguments166 = array();
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments167 = array();
$arguments167['key'] = 'set';
$arguments167['id'] = NULL;
$arguments167['default'] = NULL;
$arguments167['htmlEscape'] = NULL;
$arguments167['arguments'] = NULL;
$arguments167['extensionName'] = NULL;
$renderChildrenClosure168 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper169 = $self->getViewHelper('$viewHelper169', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper169->setArguments($arguments167);
$viewHelper169->setRenderingContext($renderingContext);
$viewHelper169->setRenderChildrenClosure($renderChildrenClosure168);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments166['value'] = $viewHelper169->initializeArgumentsAndRender();
$arguments166['additionalAttributes'] = NULL;
$arguments166['name'] = NULL;
$arguments166['property'] = NULL;
$arguments166['disabled'] = NULL;
$arguments166['class'] = NULL;
$arguments166['dir'] = NULL;
$arguments166['id'] = NULL;
$arguments166['lang'] = NULL;
$arguments166['style'] = NULL;
$arguments166['title'] = NULL;
$arguments166['accesskey'] = NULL;
$arguments166['tabindex'] = NULL;
$arguments166['onclick'] = NULL;
$renderChildrenClosure170 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper171 = $self->getViewHelper('$viewHelper171', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper');
$viewHelper171->setArguments($arguments166);
$viewHelper171->setRenderingContext($renderingContext);
$viewHelper171->setRenderChildrenClosure($renderChildrenClosure170);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper

$output145 .= $viewHelper171->initializeArgumentsAndRender();

$output145 .= '
					';
return $output145;
};
$viewHelper172 = $self->getViewHelper('$viewHelper172', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper');
$viewHelper172->setArguments($arguments143);
$viewHelper172->setRenderingContext($renderingContext);
$viewHelper172->setRenderChildrenClosure($renderChildrenClosure144);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper

$output25 .= $viewHelper172->initializeArgumentsAndRender();

$output25 .= '
				</td>

				<th>
					<label for="belog-action">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments173 = array();
$arguments173['key'] = 'action';
$arguments173['id'] = NULL;
$arguments173['default'] = NULL;
$arguments173['htmlEscape'] = NULL;
$arguments173['arguments'] = NULL;
$arguments173['extensionName'] = NULL;
$renderChildrenClosure174 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper175 = $self->getViewHelper('$viewHelper175', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper175->setArguments($arguments173);
$viewHelper175->setRenderingContext($renderingContext);
$viewHelper175->setRenderChildrenClosure($renderChildrenClosure174);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output25 .= $viewHelper175->initializeArgumentsAndRender();

$output25 .= '</label>
				</th>
				<td>
					';
// Rendering ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper
$arguments176 = array();
$arguments176['property'] = 'action';
$arguments176['options'] = TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode::getPropertyPath($renderingContext->getTemplateVariableContainer(), 'settings.selectableActions', $renderingContext);
$arguments176['optionLabelPrefix'] = 'LLL:EXT:belog/Resources/Private/Language/locallang.xlf:';
// Rendering Array
$array177 = array();
$array177['onchange'] = 'submit()';
$arguments176['additionalAttributes'] = $array177;
$arguments176['id'] = 'belog-action';
$arguments176['name'] = NULL;
$arguments176['value'] = NULL;
$arguments176['class'] = NULL;
$arguments176['dir'] = NULL;
$arguments176['lang'] = NULL;
$arguments176['style'] = NULL;
$arguments176['title'] = NULL;
$arguments176['accesskey'] = NULL;
$arguments176['tabindex'] = NULL;
$arguments176['onclick'] = NULL;
$arguments176['multiple'] = NULL;
$arguments176['size'] = NULL;
$arguments176['disabled'] = NULL;
$arguments176['optionValueField'] = NULL;
$arguments176['optionLabelField'] = NULL;
$arguments176['sortByOptionLabel'] = false;
$arguments176['selectAllByDefault'] = false;
$arguments176['errorClass'] = 'f3-form-error';
$arguments176['prependOptionLabel'] = NULL;
$arguments176['prependOptionValue'] = NULL;
$renderChildrenClosure178 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper179 = $self->getViewHelper('$viewHelper179', $renderingContext, 'TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper');
$viewHelper179->setArguments($arguments176);
$viewHelper179->setRenderingContext($renderingContext);
$viewHelper179->setRenderChildrenClosure($renderChildrenClosure178);
// End of ViewHelper TYPO3\CMS\Belog\ViewHelpers\Form\TranslateLabelSelectViewHelper

$output25 .= $viewHelper179->initializeArgumentsAndRender();

$output25 .= '
				</td>

				<th>
					<label for="belog-group">';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper
$arguments180 = array();
$arguments180['key'] = 'groupByPage';
$arguments180['id'] = NULL;
$arguments180['default'] = NULL;
$arguments180['htmlEscape'] = NULL;
$arguments180['arguments'] = NULL;
$arguments180['extensionName'] = NULL;
$renderChildrenClosure181 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper182 = $self->getViewHelper('$viewHelper182', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper');
$viewHelper182->setArguments($arguments180);
$viewHelper182->setRenderingContext($renderingContext);
$viewHelper182->setRenderChildrenClosure($renderChildrenClosure181);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper

$output25 .= $viewHelper182->initializeArgumentsAndRender();

$output25 .= '</label>
				</th>
				<td>
					';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\CheckboxViewHelper
$arguments183 = array();
$arguments183['property'] = 'groupByPage';
$arguments183['value'] = '1';
// Rendering Array
$array184 = array();
$array184['onchange'] = 'submit()';
$arguments183['additionalAttributes'] = $array184;
$arguments183['id'] = 'belog-group';
$arguments183['checked'] = NULL;
$arguments183['name'] = NULL;
$arguments183['disabled'] = NULL;
$arguments183['errorClass'] = 'f3-form-error';
$arguments183['class'] = NULL;
$arguments183['dir'] = NULL;
$arguments183['lang'] = NULL;
$arguments183['style'] = NULL;
$arguments183['title'] = NULL;
$arguments183['accesskey'] = NULL;
$arguments183['tabindex'] = NULL;
$arguments183['onclick'] = NULL;
$renderChildrenClosure185 = function() use ($renderingContext, $self) {
return NULL;
};
$viewHelper186 = $self->getViewHelper('$viewHelper186', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\Form\CheckboxViewHelper');
$viewHelper186->setArguments($arguments183);
$viewHelper186->setRenderingContext($renderingContext);
$viewHelper186->setRenderChildrenClosure($renderChildrenClosure185);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\CheckboxViewHelper

$output25 .= $viewHelper186->initializeArgumentsAndRender();

$output25 .= '
				</td>

				<th></th><td></td>
			</tr>
		</tbody>
	</table>
';
return $output25;
};
$viewHelper187 = $self->getViewHelper('$viewHelper187', $renderingContext, 'TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper');
$viewHelper187->setArguments($arguments23);
$viewHelper187->setRenderingContext($renderingContext);
$viewHelper187->setRenderChildrenClosure($renderChildrenClosure24);
// End of ViewHelper TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper

$output0 .= $viewHelper187->initializeArgumentsAndRender();

return $output0;
}


}
#1413340042    60091     