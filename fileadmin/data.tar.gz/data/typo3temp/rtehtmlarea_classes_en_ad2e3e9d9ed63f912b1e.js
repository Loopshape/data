HTMLArea.classesLabels = {"align-left":"Justify Left","align-center":"Justify Center","align-right":"Justify Right","csc-frame-frame1":"Frame with grey background","csc-frame-frame2":"Frame with yellow background","important":"Important","name-of-person":"Name of person","detail":"Detail","component-items":"Component items","action-items":"Action items","component-items-ordered":"Component items","action-items-ordered":"Action items"};
HTMLArea.classesValues = {"align-left":"text-align: left;","align-center":"text-align: center;","align-right":"text-align: right;","csc-frame-frame1":"background-color: #EDEBF1; border: 1px solid #333333;","csc-frame-frame2":"background-color: #F5FFAA; border: 1px solid #333333;","important":"color: #8A0020;","name-of-person":"color: #10007B;","detail":"color: #186900;","component-items":"color: #186900;","action-items":"color: #8A0020;","component-items-ordered":"color: #186900;","action-items-ordered":"color: #8A0020;"};
HTMLArea.classesNoShow = {};
HTMLArea.classesAlternating = {};
HTMLArea.classesCounting = {};
HTMLArea.classesXOR = {};
